# Workshop project

Starter folder for the AI Research Workshop, 6 November 2026.

| Folder | Contents |
|:--|:--|
| `code/` | Numbered scripts |
| `data/` | Input data |
| `figures/` | Figures written by the scripts |
| `tables/` | Tables written by the scripts |
| `papers/` | PDFs you are reading |
| `exercises/` | Files for the hands-on exercises |
| `workshop-materials/` | Offline guides and slides, all Quarto sources, starter files and guard |

Saved copies of the morning data are in `/opt/workshop-data/` and `workshop-materials/workshop-data/`. Open `workshop-materials/index.html` on your laptop after downloading the folder, or use the website while in Coder. If you only downloaded the small starter ZIP, get the full [take-home package](https://christianengels.net/ai-workshop-2026-11/workshop-take-home.zip) too.

To set something up or get unstuck, ask Claude: `/workshop-queries <what you want to do>`. It follows the runbooks, in `.claude/skills/workshop-queries/`.

Slides and guides: <https://christianengels.net/ai-workshop-2026-11/>

The workspace is deleted on Saturday 7 November. Push anything you want to keep to GitHub.
