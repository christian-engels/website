# Workshop project

Starter folder for the AI Research Workshop, 6 November 2026.

| Folder | Contents |
|:--|:--|
| `code/` | Numbered scripts |
| `data/` | Input data |
| `figures/` | Figures written by the scripts |
| `tables/` | Tables written by the scripts |
| `papers/` | PDFs you are reading |
| `exercises/` | Files for the hands-on exercises |

Saved copies of the morning data are in `/opt/workshop-data/`.

To set something up or get unstuck, ask Claude: `/workshop-queries <what you want to do>`. It follows tested runbooks, in `.claude/skills/workshop-queries/`.

Slides and guides: <https://christianengels.net/ai-workshop-2026-11/>

The workspace is deleted on Saturday 7 November. Push anything you want to keep to GitHub.
