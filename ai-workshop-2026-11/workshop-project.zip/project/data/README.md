# Data

Keep raw data here and do not edit it by hand.

Saved copies for the workshop exercises, in `/opt/workshop-data/`:

- `dow_constituents.csv`: 30 firms
- `dow_prices_2000_2024.csv.gz`: 184,323 daily prices
- `ibex_selected_prices_2015_2024.csv.gz`: SAN, BBVA, ITX and IBE, 2,560 days each
