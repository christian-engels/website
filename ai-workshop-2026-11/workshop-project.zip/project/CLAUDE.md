# Workshop project

A research project for the AI Research Workshop.

## Folders

- `code/`: numbered scripts, such as `01-apple_returns.R`
- `data/`: input data and data saved by the scripts
- `figures/`: figures written by the scripts
- `tables/`: tables written by the scripts
- `papers/`: PDFs being read
- `manuscript/`: the LaTeX manuscript, once there is one
- `exercises/`: files for the hands-on exercises

Saved copies of the workshop data are in `/opt/workshop-data/` and `workshop-materials/workshop-data/`. The latter also contains all slides, guides and editable Quarto sources. Use public or synthetic data for the exercises.

## Rules

- Do analysis in R or Python, in a script saved in `code/`, so that it can be run again from scratch.
- Number scripts in the order they run. One script, one output.
- Run scripts from the project folder and use relative paths.
- Use `uv` for project Python environments and `rig` plus `renv` for R projects. Restore existing lockfiles; do not install project packages globally.
- Never edit raw data by hand.
- Numbers in the paper come from `tables/` and `figures/`. Do not type them in by hand.
- Read API keys from `.env`. Never write them in a script or repeat them in the conversation. If a key was pasted into chat, tell the participant to revoke it and put a replacement in `.env` themselves.
