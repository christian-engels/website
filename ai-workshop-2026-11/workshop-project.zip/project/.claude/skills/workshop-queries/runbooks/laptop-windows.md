# Install the tools on Windows

Status: Not validated. No Windows machine was available. Written from each tool's documentation. Say so and ask before you start.
Runs in: laptop. Cost: free, plus a Claude subscription. Time: 30 to 60 minutes.

## Terms

- **PowerShell:** the Windows terminal. Press the Windows key, type `PowerShell` and press Enter.
- **winget:** the installer built into Windows.

These commands are for PowerShell. If Claude Code is not installed yet, the participant follows these steps from the guide at <https://christianengels.net/ai-workshop-2026-11/own-machine.html>.

## 1. Git and the GitHub CLI

```powershell
winget install --id Git.Git
winget install --id GitHub.cli
```

Close PowerShell and open it again.

Check: `git --version` and `gh --version`.

Then sign in: `git-and-github.md` step 1.

## 2. Claude Code

```powershell
irm https://claude.ai/install.ps1 | iex
```

Close PowerShell and open it again, then run `claude` and sign in.

## 3. `uv`

```powershell
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```

Check: `uv --version`, in a new window.

## 4. VS Code and R

```powershell
winget install --id Microsoft.VisualStudioCode
winget install --id posit.rig
```

Open a new terminal and run `rig add release`. In VS Code, install the Claude Code extension.

## 5. LaTeX

Follow <https://yihui.org/tinytex/> for Windows, then run `tlmgr install latexmk`.

## 6. Your project

`git-and-github.md` step 5. Use `copy .env.example .env` in place of `cp`.

## If it goes wrong

- `is not recognized as a name of a cmdlet`: close PowerShell and open it again.

## Project packages

Use `rig` for R versions, `renv` for project R libraries and `uv` for project Python environments. Follow the R and Python section of the setup guide (also in `workshop-materials/own-machine.html`). Do not install project packages globally. For existing projects, restore their lockfiles; do not initialise over them.
