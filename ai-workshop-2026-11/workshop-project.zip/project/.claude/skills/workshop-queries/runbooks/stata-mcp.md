# Use Stata from Claude Code

Status: Partly validated. On 4 November 2026 the server connected on a Mac. The regression was not run, because the licence on that machine had expired.
Runs in: laptop only. Workspaces have no Stata. Cost: your Stata licence. Time: 10 minutes.
Needs: Claude Code and `uv` on the laptop, and a licensed Stata.

## 1. Check the setup

```bash
uvx stata-mcp doctor
```

## 2. Add the server

```bash
claude mcp add stata-mcp --scope user -- uvx stata-mcp
```

Restart Claude.

Check: `/mcp` shows `stata-mcp` as connected.

## 3. Run a real regression

```
Run sysuse auto, then regress price mpg weight, and show me the table.
```

Check: a regression table with 74 observations appears. This is the real test: with an expired licence, `doctor` passes and the tool reports success with no output.

## If it goes wrong

- No output and no error: check the Stata licence.

Output that Claude reads goes to Anthropic, so take care with confidential data.
