# OpenAlex, Crossref and Consensus

Status: Partly validated, 5 November 2026, from a workshop workspace.
Run: OpenAlex search and DOI lookup without a key, Crossref lookup, adding Consensus (shown as connected).
Not run: OpenAlex with a real key, and signing in to Consensus.
Runs in: workspace or laptop. Cost: free. Time: 10 minutes.

## Terms

- **DOI:** a permanent identifier for a paper. **Metadata:** title, authors, year and journal.
- **Rate limit:** how many requests a service allows in a period.

## OpenAlex

No key is needed, but without one everyone on the same network shares $0.10 of searches a day, about 100. In a workshop that means the whole room. A free key gives $1 a day of your own.

1. The participant signs in at <https://openalex.org/settings/api> and copies the key
2. Add it to `.env` as `OPENALEX_API_KEY`: see `api-keys.md`

Test without a key:

```bash
curl -s 'https://api.openalex.org/works/doi:10.1111/jofi.12162?select=title,cited_by_count'
```

Check: it returns the title `Measuring Readability in Financial Disclosures`.

With a key, add `&api_key=$OPENALEX_API_KEY` to the address after loading `.env`. A wrong key gives `401`.

## Crossref

No key. Add an email address as `mailto` for a higher rate limit.

```bash
curl -s 'https://api.crossref.org/works/10.1111/jofi.12162'
```

Check: the response contains the same title.

## Consensus

In the terminal, not inside Claude:

```bash
claude mcp add --transport http consensus https://mcp.consensus.app/mcp
```

Check: `claude mcp list` shows `consensus` as connected.

Then start `claude`, run `/mcp`, choose `consensus` and sign in. Not run: the sign-in uses a browser and may not complete from a workspace. If it fails, connect Consensus at claude.ai under **Connectors** instead.

## If it goes wrong

- `429`: the shared budget is used up. Add a key.
- `401`: the key is wrong or was not loaded.
