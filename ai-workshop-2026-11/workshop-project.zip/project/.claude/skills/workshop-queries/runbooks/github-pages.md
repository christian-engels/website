# Publish a website with GitHub Pages

Status: Partly validated, 5 November 2026, from a workshop workspace.
Run: publishing from `docs/` with the commands below, live in 56 seconds; `/site` refused. The DNS records are those of a working site.
Not run: a public repository on a free plan (the test account is paid), a repository named `<username>.github.io`, and the Namecheap screens.
Runs in: workspace or laptop. Cost: free; a domain costs about €10 to €15 a year. Time: 15 minutes, plus up to 24 hours for a domain.
Needs: `git-and-github.md` step 1.

## Terms

- **GitHub Pages:** GitHub's free hosting for web pages stored in a repository.
- **Domain:** an address such as `example.org`, rented yearly from a registrar such as Namecheap.
- **DNS:** the records that connect a domain to a server.

## Decide first

On a free plan, Pages publishes only from a public repository, according to GitHub's documentation, and then every file in it is public. Keep the site in a new repository, not in `workshop-project`. Tell the participant this and confirm before step 2.

## 1. Create the site

```bash
cd ~
mkdir my-site
cd my-site
git init -b main
mkdir docs
```

Write the page to `docs/index.html`. Pages serves only the repository's root or `docs/`; any other folder is refused.

## 2. Create the repository

```bash
git add -A
git commit -m "First version of the site"
gh repo create my-site --public --source . --remote origin --push
```

Check: `git status -sb` shows `## main...origin/main`.

## 3. Turn on Pages

```bash
OWNER=$(gh api user --jq .login)
gh api -X POST repos/$OWNER/my-site/pages -f "source[branch]=main" -f "source[path]=/docs" --jq .html_url
```

Check: it prints the address, `https://<username>.github.io/my-site/`.

## 4. Confirm that it is live

After about a minute:

```bash
gh api repos/$OWNER/my-site/pages --jq .status
curl -s -o /dev/null -w '%{http_code}\n' https://$OWNER.github.io/my-site/
```

Check: `built` and `200`. If the participant's account already has a custom domain, the second command gives a redirect code such as `301`: use the address the first page shows.

## 5. Update the site

Edit `docs/`, then commit and push. The site updates in about a minute.

## A personal address

Not run. For `https://<username>.github.io`, name the repository `<username>.github.io`. It can serve from the root: use `source[path]=/` in step 3.

## Your own domain

The participant buys the domain and makes the DNS changes. Not run on Namecheap.

```bash
gh api -X PUT repos/$OWNER/my-site/pages -f cname=example.org
```

At Namecheap, under **Advanced DNS**, add:

| Type | Host | Value |
|:--|:--|:--|
| A | `@` | `185.199.108.153` |
| A | `@` | `185.199.109.153` |
| A | `@` | `185.199.110.153` |
| A | `@` | `185.199.111.153` |
| CNAME | `www` | `<username>.github.io` |

Check: `dig +short example.org` lists the four addresses. Changes can take up to 24 hours. Then tick **Enforce HTTPS** under **Settings → Pages**.

## Turn it off

```bash
gh api -X DELETE repos/$OWNER/my-site/pages
```

## If it goes wrong

- `/site is not a possible value. Must be one of the following: /, /docs.`: move the page into `docs/`.
- `GitHub Pages is already enabled`: Pages is on. Skip step 3.
- 404 straight after publishing: wait a minute and try again.
- Pages is refused on a private repository: on a free plan, the repository must be public.
