# Other models through OpenRouter

Status: Partly validated, 5 November 2026. The workspace section was run from start to finish on the workshop key, on Haiku 5.5. Steps 1 to 4, with the participant's own key, have not been run: say so and ask before you start them.
Runs in: workspace or laptop. Cost: pay per use. Set a credit limit first. Time: 10 minutes.

## Terms

- **OpenRouter:** one account and one key for many companies' models.
- **Credit limit:** the most a key can spend.

## In a workspace: the workshop key

A workspace already has a shared key in `OPENROUTER_API_KEY`, so there is nothing to create or paste. The key allows only Claude Haiku 5.5, Sonnet 5.5 and Opus 5.5, on zero-retention endpoints. Everyone shares its $50 limit.

To run Claude Code on it:

```bash
ori claude --model anthropic/claude-haiku-5.5
```

Check: Claude Code starts without asking how to sign in. A first run also shows Claude Code's theme picker.

Use Haiku unless the participant has a reason not to. A one-word reply cost about half a cent on Haiku and 25 cents on Opus, because every session starts with a long prompt. Without `--model`, `ori claude` may start on Opus.

For the optional hooks and data guard, follow `wrds-guard.md`: copy `/opt/wrds-guard`, enter it,
and run `bin/claude-openrouter`. This is still Claude Code with the same OpenRouter key. Normal workshop
exercises continue to use `claude` with the participant's own subscription.

The shared key expires on 12 November 2026 at 15:43 UTC. The server and workspaces are deleted on 7 November.

Any other model needs the participant's own key: follow the steps below.

## 1. Create a key

The participant does this at <https://openrouter.ai/settings/keys>, sets a credit limit and copies the key. Review <https://openrouter.ai/settings/privacy> first: providers differ in what they keep.

## 2. Add it to `.env`

`OPENROUTER_API_KEY`: see `api-keys.md`.

## 3. Run a small test first

Write a script that sends one short request to `https://openrouter.ai/api/v1/chat/completions` with one fixed model, then prints the reply and the model name returned.

Check: one reply, and a small charge on the OpenRouter activity page.

## 4. Run the batch

Confirm the likely cost with the participant. Save each reply with the model name and the time. Pin one specific model for research labels, so that the results can be reproduced.

## If it goes wrong

- `401`: the key is wrong or was not loaded.
- `402`: the credit limit has been reached.
- `404` mentioning guardrail restrictions: the workshop key does not allow that model. Use one of the three Claude 5.5 models, or the participant's own key.
