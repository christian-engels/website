# Other models through OpenRouter

Status: Not validated. Written from OpenRouter's documentation. On 5 November 2026 the public model list loaded (455 models) and a request with no key returned `401`; no paid request was made. Say so and ask before you start.
Runs in: workspace or laptop. Cost: pay per use. Set a credit limit first. Time: 10 minutes.

## Terms

- **OpenRouter:** one account and one key for many companies' models.
- **Credit limit:** the most a key can spend.

## 1. Create a key

The participant does this at <https://openrouter.ai/settings/keys>, sets a credit limit and copies the key. Review <https://openrouter.ai/settings/privacy> first: providers differ in what they keep.

## 2. Add it to `.env`

`OPENROUTER_API_KEY`: see `api-keys.md`.

## 3. Run a small test first

Write a script that sends one short request to `https://openrouter.ai/api/v1/chat/completions` with one fixed model, then prints the reply and the model name returned.

Check: one reply, and a small charge on the OpenRouter activity page.

## 4. Run the batch

Confirm the likely cost with the participant. Save each reply with the model name and the time. Pin one specific model for research labels, so that the results can be reproduced.

## If it goes wrong

- `401`: the key is wrong or was not loaded.
- `402`: the credit limit has been reached.
