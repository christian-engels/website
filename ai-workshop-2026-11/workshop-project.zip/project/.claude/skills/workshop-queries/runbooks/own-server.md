# Rent a server and make it safe

Status: Partly validated, 5 November 2026, on a real Hetzner cx23 server with Ubuntu 24.04: every command below, including the reboot and the deletion.
Not run: the Hetzner sign-up and console screens (the test server was created through the API). Other providers were not tested.
Runs in: laptop (recommended) or workspace, plus the provider's website. Time: 20 minutes, and sign-up can take longer.
Cost: cx23, 2 processors and 4 GB of memory: €6.59 a month or about €0.011 an hour, with VAT, on 5 November 2026. Check the price shown at sign-up.
Needs: `ssh-keys.md` steps 1 and 2, and a payment card.

## Terms

- **Provider:** the company that rents the server. **Root:** the administrator account.
- **Firewall:** rules that decide which connections reach the server. **Port:** a numbered door for a service; SSH uses 22.

A switched-off server still costs money. Only deleting it stops the charge. Confirm the cost with the participant before step 1.

## 1. Create the server

The participant does this at <https://console.hetzner.com>. Sign-up may ask for an identity check.

1. Create a project
2. Choose **Add Server**
3. Choose a location, **Ubuntu 24.04** and type **CX23**
4. Under SSH keys, add the public key from `ssh-keys.md` step 2
5. Create the server and note its IPv4 address

## 2. Connect

Follow `ssh-keys.md` step 3.

Check: `lsb_release -ds` shows Ubuntu 24.04.

## 3. Update it

On the server:

```bash
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get -y upgrade
```

## 4. Turn on the firewall

```bash
ufw allow OpenSSH
ufw --force enable
```

Check: `ufw status` shows `Status: active` and `OpenSSH ALLOW`.

Allow OpenSSH first, or you lock yourself out.

## 5. Turn off password login

The server allows passwords by default. Keys are safer.

```bash
printf 'PasswordAuthentication no\n' > /etc/ssh/sshd_config.d/10-no-passwords.conf
sshd -t && systemctl reload ssh
```

Check: `sshd -T | grep passwordauthentication` shows `passwordauthentication no`.

## 6. Restart if asked

```bash
ls /var/run/reboot-required
```

If the file exists, run `reboot`. The connection closes. Wait 30 seconds, then connect again.

Check: `uptime -p` shows a short time.

Security updates install automatically on this image.

## 7. Delete the server

The participant does this when finished: in the console, open the server and choose **Delete**. Remind them when you finish any work on the server.

## If it goes wrong

- Locked out: use the **Console** button on the server's page in the Hetzner console, or delete the server and start again.
- See `ssh-keys.md` for connection errors.
