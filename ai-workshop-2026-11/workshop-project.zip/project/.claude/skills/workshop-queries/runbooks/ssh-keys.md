# SSH keys: connect to a server and copy files

Status: Validated, 5 November 2026, from a workshop workspace to a new Ubuntu 24.04 server: key creation, first connection, copying a file both ways.
Runs in: laptop (recommended) or workspace. A key made in a workspace is deleted with it. Cost: free. Time: 5 minutes.

## Terms

- **Server:** a computer that runs all the time in a data centre.
- **SSH:** a secure way to open a terminal on another computer.
- **Key pair:** two files. The private key stays on your machine and acts as your identity. The public key goes on the server.
- **Passphrase:** an optional password that protects the private key.

Never show or copy `id_ed25519`, the file without `.pub`.

## 1. Create a key (once per machine)

```bash
ls ~/.ssh/id_ed25519.pub
```

If the file exists, go to step 2. If not, ask the participant to run this, because it asks questions at the keyboard:

```bash
ssh-keygen -t ed25519 -C "my-laptop"
```

Press Enter to accept the file name. Enter a passphrase, or press Enter twice for none.

Check: `ls -la ~/.ssh` lists `id_ed25519` with `-rw-------` and `id_ed25519.pub`.

## 2. Show the public key

```bash
cat ~/.ssh/id_ed25519.pub
```

It is one line starting `ssh-ed25519`. This is the text to give the provider. It is safe to share.

## 3. Connect

```bash
ssh root@<address>
```

The first time, it asks:

```
The authenticity of host '<address>' can't be established.
ED25519 key fingerprint is SHA256:...
Are you sure you want to continue connecting (yes/no/[fingerprint])?
```

Type `yes` and press Enter. This records the server's identity.

Check: the prompt changes to `root@<name>`. Everything typed now runs on the server. `exit` returns to your machine.

## 4. Copy files

Run these on your own machine, not on the server:

```bash
scp data.csv root@<address>:/root/
scp root@<address>:/root/results.csv .
```

Check: `ls` shows the file. The `.` means the current folder.

## If it goes wrong

- `Permission denied (publickey)`: the server does not have this public key. Check that the key given to the provider matches step 2.
- `Connection timed out`: wrong address, the server is off, or a firewall blocks port 22.
- `REMOTE HOST IDENTIFICATION HAS CHANGED`: expected only if the server was rebuilt. If so, run `ssh-keygen -R <address>` and connect again. If not, stop and ask for help.
- `Host key verification failed`: the fingerprint question was not answered with `yes`. Connect again.
- `ssh: command not found` in a workspace created before 5 November: recreate the workspace, or use a laptop.
