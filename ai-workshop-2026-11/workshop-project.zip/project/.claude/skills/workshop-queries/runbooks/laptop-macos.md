# Install the tools on a Mac

Status: Partly validated, 5 November 2026. The Claude Code, `uv` and TinyTeX installers, the MCP commands and `git clone` were run on a clean Ubuntu server, not a clean Mac. Homebrew, the VS Code and R installs and the desktop app were not run. Tell the participant before you start.
Runs in: laptop. Cost: free, plus a Claude subscription. Time: 30 to 60 minutes.

## Terms

- **Terminal:** on a Mac, press `Cmd+Space`, type `Terminal` and press Enter.
- **Homebrew:** an installer for command-line tools.

If Claude Code is not installed yet, the participant follows these steps from the guide at <https://christianengels.net/ai-workshop-2026-11/own-machine.html>.

## 1. Git

```bash
git --version
```

If a window offers to install the developer tools, accept it, wait, then run the command again.

Check: it prints a version.

## 2. Homebrew

The participant runs this, because it asks for the Mac's password. Nothing appears on screen while typing a password. That is normal.

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

At the end it prints **Next steps**: run those lines.

Check: `brew --version`.

## 3. GitHub CLI

```bash
brew install gh
```

Then sign in: `git-and-github.md` step 1.

## 4. Claude Code

```bash
curl -fsSL https://claude.ai/install.sh | bash
```

Open a new terminal window, then run `claude` and sign in.

## 5. `uv`

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

Open a new terminal window. Check: `uv --version`.

## 6. VS Code and R

```bash
brew install --cask visual-studio-code
brew install --cask r
```

In VS Code, install the Claude Code extension.

Check: `R --version`.

## 7. LaTeX

```bash
curl -sL https://yihui.org/tinytex/install-bin-unix.sh | sh
```

Open a new terminal window, then:

```bash
tlmgr install latexmk
```

Check: `latexmk --version`.

## 8. Your project

`git-and-github.md` step 5. Then `cp -r .claude/skills/workshop-queries ~/.claude/skills/` makes these runbooks available in every project.

## If it goes wrong

- `command not found` straight after an install: open a new terminal window. If it persists for `claude` or `uv`, run `echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.zshrc` and open a new window. Not run on a Mac.
- `brew: command not found`: the **Next steps** lines from step 2 were not run.
