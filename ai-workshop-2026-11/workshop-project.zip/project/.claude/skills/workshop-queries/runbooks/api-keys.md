# API keys and the `.env` file

Status: Validated, 5 November 2026, in a workshop workspace: reading a key from the shell, R and Python, and the `.gitignore` check.
Runs in: workspace or laptop. Cost: free. Time: 5 minutes.

## Terms

- **API:** a way for a program to ask a service for data.
- **API key:** a long password that identifies you to that service. Anyone who has it can use your account.
- **`.env`:** a text file in the project that holds keys, so that they stay out of your code.

Never read or print `.env`. Keys must not appear in the conversation.

## 1. Create the file (once per project)

```bash
ls -a
```

If `.env` is not listed:

```bash
cp .env.example .env
```

## 2. Add the key

The participant does this. Ask them to open `.env` in the VS Code Explorer and paste the key after the `=`, then save:

```
OPENALEX_API_KEY=the-key-goes-here
```

Use no spaces and no quotation marks.

## 3. Confirm that Git ignores it

```bash
git check-ignore .env
```

Check: it prints `.env`. If it prints nothing, stop: add `.env` to `.gitignore` before any commit.

## 4. Read the key from code

Check that it loads without showing it. The shell prints only the number of characters:

```bash
set -a; . ./.env; set +a
echo ${#OPENALEX_API_KEY}
```

In R:

```r
readRenviron(".env")
Sys.getenv("OPENALEX_API_KEY")
```

In Python, with `python-dotenv` installed (`uv add python-dotenv`):

```python
import os
from dotenv import load_dotenv
load_dotenv(".env")
key = os.environ["OPENALEX_API_KEY"]
```

Check: the length is above 0.

## If it goes wrong

- The length is 0: the file was not saved, the name differs from the one used in the code, or the command was run outside the project folder.
- A key was pasted into the conversation, committed or pushed: treat it as public. The participant signs in to the provider, deletes the key and creates a new one. Deleting the file or the commit is not enough, because the key remains in the history.
