# Run RStudio on a server

Status: Validated, 5 November 2026, on a Hetzner cx23 with Ubuntu 24.04: a real browser sign-in through the tunnel from a workshop workspace, and the service returning after a reboot.
Runs in: on a server, viewed from a laptop. Cost: the server's. Time: 10 minutes. Disk: about 3 GB.
Needs: `own-server.md` up to step 6.

## Terms

- **Docker:** runs a program in a sealed box, with everything it needs.
- **SSH tunnel:** a private connection that makes a port on the server appear on your machine. RStudio is then reachable only by you.

## 1. Install Docker

On the server:

```bash
apt-get install -y docker.io
```

Check: `docker --version` prints a version.

## 2. Start RStudio

Ask the participant to run this on the server, so that the password stays out of the conversation:

```bash
read -rsp 'Choose a password: ' RS_PW; echo
docker run -d --name rstudio --restart unless-stopped -p 127.0.0.1:8787:8787 -e PASSWORD="$RS_PW" -v rstudio-home:/home/rstudio rocker/rstudio
unset RS_PW
```

Keep `127.0.0.1:` in that line. Docker ignores the firewall, so without it RStudio is open to the internet.

- `--restart unless-stopped`: starts again after a reboot
- `-v rstudio-home:/home/rstudio`: keeps files if the container is replaced

Check: `docker ps` lists `rstudio` with `127.0.0.1:8787->8787/tcp`, and `curl -s -o /dev/null -w '%{http_code}\n' localhost:8787` prints `302`.

## 3. Open the tunnel

On your own machine, in a new terminal:

```bash
ssh -N -L 8787:localhost:8787 root@<address>
```

It prints nothing and keeps running. That is correct. `Ctrl+C` closes it.

## 4. Sign in

Open <http://localhost:8787>. The username is `rstudio`, and the password is the one chosen in step 2.

Check: the RStudio console appears.

From a workspace, `localhost` is the workspace, not your laptop. Use the workspace browser, or run the tunnel from your laptop.

## 5. Confirm that it is private

On your own machine:

```bash
curl -m 5 http://<address>:8787
```

Check: it times out. If a page appears, stop the container and repeat step 2 with `127.0.0.1:`.

## Stop and restart

```bash
docker stop rstudio
docker start rstudio
```

Delete the server when finished: `own-server.md` step 7.

## If it goes wrong

- `bind: address already in use` when opening the tunnel: a tunnel is already open, or something else uses port 8787.
- `Connection refused` in the browser: the tunnel is not running.
- Sign-in fails: the username is `rstudio`, not `root`.
