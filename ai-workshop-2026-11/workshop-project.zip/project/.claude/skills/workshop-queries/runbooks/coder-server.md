# Run Coder on a server

Status: Partly validated, 5 November 2026, with Coder 2.39.0 on a Hetzner cx23 with Ubuntu 24.04: install, first account, template and a healthy workspace in 46 seconds.
Not run: opening the workspace page in a browser. The test checked the workspace from the command line.
Runs in: on a server. Cost: the server's. Time: 15 minutes.
Needs: `own-server.md` up to step 6, and Docker from `rstudio-server.md` step 1.

## Terms

- **Coder:** gives each person a personal workspace on a server, as in this workshop.
- **Template:** the recipe for a workspace.

## 1. Install

On the server:

```bash
curl -fsSL https://coder.com/install.sh | sh
usermod -aG docker coder
```

Do not run `coder server` by hand as root. It stops with `The built-in PostgreSQL cannot run as the root user`. Coder runs as a service under its own user instead.

## 2. Start the service

```bash
sed -i 's/^CODER_HTTP_ADDRESS=.*/CODER_HTTP_ADDRESS=127.0.0.1:3000/' /etc/coder.d/coder.env
systemctl enable --now coder
```

Without that address, the service stops with `TLS is disabled`.

Check: `systemctl is-active coder` prints `active`.

## 3. Find the address

Coder creates a public address for you:

```bash
journalctl -u coder --no-pager | grep -oE 'https://[a-z0-9]+\.[a-z0-9-]+\.try\.coder\.app' | tail -1
```

Check: `curl -s -o /dev/null -w '%{http_code}\n' <address>/healthz` prints `200`.

This address suits trials. For regular use, Coder's documentation explains how to use your own domain.

## 4. Create the first account

Do this straight away: the first person to claim the address becomes the administrator. Ask the participant to run this on the server, so that the password stays out of the conversation. Use a long password.

```bash
read -rsp 'Choose a password: ' CODER_PW; echo
sudo -u coder -H coder login <address> --first-user-username <name> --first-user-email <email> --first-user-password "$CODER_PW" --first-user-full-name "<name>" --first-user-trial=false
unset CODER_PW
```

Check: it prints `Welcome to Coder`.

## 5. Add a template

```bash
sudo -u coder -H bash -lc 'cd /tmp && coder templates init --id docker tpl && coder templates push docker -d tpl --yes'
```

Check: it ends with `Updated version at`.

## 6. Create a workspace

```bash
sudo -u coder -H coder create mine --template docker --parameter "jetbrains_ides=[]" --yes
```

Check: `sudo -u coder -H coder list` shows `Started` and `true` under HEALTHY.

The participant opens the address and selects the workspace to use it.

Delete the server when finished: `own-server.md` step 7.

## If it goes wrong

- `value "" is not a valid list of strings`, shown as `terraform plan: exit status 1`: the `--parameter "jetbrains_ides=[]"` part is missing.
- `activating (auto-restart)` from `systemctl status coder`: read `journalctl -u coder -n 30 --no-pager`.
- Permission errors about Docker: run `usermod -aG docker coder`, then `systemctl restart coder`.
