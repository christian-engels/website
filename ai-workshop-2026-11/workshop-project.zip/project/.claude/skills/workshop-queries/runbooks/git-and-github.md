# GitHub: sign in, save and undo

Status: Partly validated, 5 November 2026, in a workshop workspace against a real GitHub repository: steps 2 to 5 and the errors below, except where marked.
Not run: the browser screens of `gh auth login`. The test signed in with a token; the first three questions were checked.
Runs in: workspace or laptop. Cost: free. Time: 10 minutes.
Needs: a GitHub account.

## Terms

- **Git:** a program that records versions of a folder. It runs on your machine.
- **GitHub:** a website that stores a copy of that history.
- **Repository (repo):** a folder that Git tracks.
- **Commit:** a saved version, with a message saying what changed.
- **Push:** send your commits to GitHub. **Pull:** fetch commits from GitHub.
- **Clone:** download a repository to a new machine.

## 1. Sign in (once per machine)

```bash
gh auth status
```

If it shows `Logged in to github.com`, go to step 2. Otherwise ask the participant to run this in the terminal, because it asks questions at the keyboard:

```bash
gh auth login
```

| Question | Answer |
|:--|:--|
| What account do you want to log into? | GitHub.com |
| What is your preferred protocol for Git operations on this host? | HTTPS (not SSH) |
| Authenticate Git with your GitHub credentials? | Yes |
| How would you like to authenticate GitHub CLI? | Login with a web browser |

It then prints a one-time code. Copy it, press Enter, and paste the code at <https://github.com/login/device>, then choose **Authorize**.

In the VS Code terminal, copy with `Ctrl+Shift+C` (`Cmd+C` on a Mac). `Ctrl+C` cancels the sign-in.

Check: `gh auth status` shows `Logged in to github.com account <name>`.

## 2. Connect the project to GitHub (once per project)

```bash
git remote -v
```

If this prints `origin`, the project is already connected: go to step 3. Otherwise:

```bash
gh repo create workshop-project --private --source . --remote origin --push
```

`--private` means only the participant can see it. Ask before using `--public`.

Check: `git status -sb` shows `## main...origin/main`, and the command printed the repository's address.

## 3. Save work (each time)

```bash
git status
```

Read the list. Stop and ask if it includes `.env`, a key, or a file over 50 MB. Then:

```bash
git add -A
git commit -m "Describe what changed"
git push
```

Check: `git status -sb` shows `## main...origin/main` with no `ahead`, and no files listed.

## 4. Look back and undo

| To | Run |
|:--|:--|
| See recent versions | `git log --oneline -10` |
| See what changed | `git status`, then `git diff` |
| Discard an edit not yet committed | `git restore <file>` |
| Undo the last commit but keep the work | `git reset --soft HEAD~1` |
| Reverse a commit already pushed | `git revert --no-edit HEAD`, then `git push` |

`git restore` deletes the edit, so confirm first.

## 5. Get the project on another machine

```bash
gh repo clone workshop-project
cd workshop-project
cp .env.example .env
```

`.env` is not on GitHub, so add the keys again.

Check: `git log --oneline` lists the commits.

## If it goes wrong

- `GraphQL: Name already exists on this account (createRepository)`: the repository already exists. If this project is already connected, step 2's first check would have shown it. Otherwise choose another name, or clone the existing one with step 5.
- `! [rejected] main -> main (fetch first)`, or `fatal: Need to specify how to reconcile divergent branches`: GitHub has commits you do not have. Run `git pull --rebase`, then `git push`.
- `GH001: Large files detected` or `exceeds GitHub's file size limit of 100.00 MB`: if the file is in the last commit, run `git reset --soft HEAD~1`, `git restore --staged <file>`, add the file's name to `.gitignore`, then commit and push again.
- `.env` was committed: run `git rm --cached .env`, then commit. The file stays on disk, but the key is still in the history. Replace the key with its provider: see `api-keys.md`.
- `fatal: not a git repository`: you are in the wrong folder. Run `cd ~/project`. Not run in the test.
- `Permission denied (publickey)`: SSH was chosen at sign-in. Run `gh auth login` again and choose HTTPS. Not run in the test.
- `Author identity unknown` or `Please tell me who you are`, on a laptop only: run `git config --global user.name "Your Name"` and `git config --global user.email "you@example.org"`. Not run in the test: workspaces set these for you.
- `GH007: Your push would publish a private email address`: on GitHub, open **Settings → Emails** and untick **Block command line pushes that expose my email**. Not run in the test.
