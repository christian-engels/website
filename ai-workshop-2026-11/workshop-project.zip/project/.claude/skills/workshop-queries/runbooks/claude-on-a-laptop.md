# Chrome, remote control, the desktop app and cloud sessions

Status: Partly validated, 5 November 2026, on a Mac: the terminal to desktop to cloud steps were used, and a cloud session pushed to GitHub. `/chrome` was tested only from a workspace, where it does not work. Remote control was not run, and nothing here was run on Windows.
Runs in: laptop only. Cost: your Claude plan. Time: 10 minutes each.
Needs: Claude Code on the laptop.

## Terminal to desktop to cloud

A cloud session keeps working with the laptop shut. It starts from what is on GitHub, so push first.

1. Push your work: `git-and-github.md` step 3
2. In the project, start `claude` and run `/web-setup`. Check: it prints `Connected as <username>`
3. Run `/desktop`. The session opens in the Claude desktop app
4. In the app, open the menu beside the session title and choose **Open in**, then **Cloud**. Read the dialog before confirming
5. Follow the session at <https://claude.ai/code>
6. To bring it back, run `/teleport` in a terminal in the project folder

The cloud machine has the repository only. `.env`, SSH keys and personal skills stay behind. These runbooks travel with the project, in `.claude/skills/`.

A cloud session pushes to its own branch, not to `main`. Run `git fetch`, then check `git branch -r` before working locally, or the two copies will diverge.

## Claude in Chrome

This does not work from a workshop workspace.

1. The participant installs the Claude in Chrome extension and signs in with the same Claude account
2. Start `claude --chrome`
3. Run `/chrome`

Check: it shows the extension as connected.

Claude can then reach any site the participant is signed in to. Sign in to sites yourself. Check a publisher's terms before downloading: bulk downloading is often not allowed.

## Remote control

Not run.

```bash
claude remote-control
```

This connects claude.ai or the Claude mobile app to a session on the laptop. Files stay on the laptop, and it must stay on.
