# Licensed data with the WRDS guard and OpenRouter

Status: OpenRouter edition, 6 November 2026. Real Claude Code 2.1.311 on the shared OpenRouter key passed the earlier synthetic summary/read-denial test; the current launcher and guard are checked in TESTING.md.
Runs in: workspace or laptop. Cost: pay per use; the workspace's shared key is funded by the organiser. Time: 10 minutes.
Needs: Claude Code and OPENROUTER_API_KEY. The workspace already supplies both. Participants use their own Claude subscription for the normal workshop exercises.

## What changes

Claude Code can use an OpenRouter key directly. Its local hooks and file tools keep working. This optional folder adds the WRDS guard; there is no custom gateway or AWS account to configure.

The guard limits what reaches the model: data and outputs stay local; Claude sees column names, types, row counts and error locations. This is one reading of the WRDS policy, not a ruling. Check the data licence with the library or vendor before using real licensed data. Practise with synthetic data first.

## 1. Copy the project

In the workspace:

```bash
cp -r /opt/wrds-guard ~/wrds-guard
cd ~/wrds-guard
```

If that folder already exists, use a new name; do not overwrite a participant's project. On a laptop, download [wrds-guard.zip](https://christianengels.net/ai-workshop-2026-11/wrds-guard.zip), unzip it and enter the folder. Load your own OpenRouter key in the terminal and enable zero retention in your OpenRouter account. Never ask the participant to paste a key into the conversation.

## 2. Check and start

```bash
python3 -m unittest discover -s tests
bin/claude-openrouter --check
bin/claude-openrouter
```

The launcher reads the existing key from the environment and defaults to **Haiku 5.5**. It sets OpenRouter routing only for this process and keeps Claude's configuration in `~/.claude-openrouter`. The participant's normal subscription login is preserved. No key is written to a settings file.

```bash
bin/claude-openrouter --model sonnet
bin/claude-openrouter --model opus
bin/claude-openrouter --continue
```

The shared key allows Haiku, Sonnet and Opus 5.5 only. Everyone shares **$50 total**, including earlier usage. It expires **12 November 2026 at 15:43 UTC**; the workspace itself is deleted on 7 November. The account already restricts requests to zero-retention endpoints. A laptop user's own key has its own limits and privacy settings.

Check `/status`: the base URL is `https://openrouter.ai/api`. The project hook describes the guard and that route. `/hooks` shows the project hooks. Do not turn off the routing check or hooks. MCP servers from the normal subscription configuration are separate; project MCP servers must also be allowed by the guard.

## 3. Try it with synthetic data

The participant puts a small CSV in `data/`, then asks:

```text
Write src/01-summary.py that reads data/<file>.csv with the csv module and writes the mean of each numeric column to output/summary.csv, then run it. Respect the guard; do not display values.
```

Check: Claude reports the output file's row count and column names, but cannot read its values. Ask to show the first rows; it should refuse. The participant opens `output/summary.csv` in the editor and copies only reviewed material into `approved/`.

The summary is evidence from this setup, not a security boundary against arbitrary hostile code. The README records the guard's limits, including scripts that deliberately copy data into prose. Review scripts and logs before using licensed material.

## If something fails

- Missing key: ask the organiser, or load a personal key in the terminal. Do not paste it into Claude.
- Missing hook or disabled routing: restore the guard files; `--check` stops before any model call.
- Routing still points to AWS: an old `.claude/settings.local.json` may override it. Preserve that file privately, remove its obsolete routing settings, then use the launcher. Do not change the normal user-wide Claude settings.
- `401`/`402`: authentication, expiry or shared credit limit; ask the organiser.
- `404` or an endpoint error: keep zero retention on; stop and report the failure.
- Encrypted-history/provider error on resume: start a new conversation from the saved files. Do not paste data or old transcript content into a prompt.
- A script fails without an explanatory error message: open the named log yourself. The guard intentionally withholds messages that might contain data values.
