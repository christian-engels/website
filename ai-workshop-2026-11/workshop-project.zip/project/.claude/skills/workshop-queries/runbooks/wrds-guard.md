# Licensed data with the WRDS guard

Status: Partly validated, 5 November 2026. The guard itself was tested in a cloud session: 28 unit tests and headless Claude sessions against a canary value. Not run: routing Claude Code through OpenRouter from a workspace, and Bedrock with a real account. Say so before you start.
Runs in: workspace, with the workshop's OpenRouter key, or laptop, with the participant's own Bedrock or OpenRouter account. Cost: the OpenRouter key is funded by the organiser; Bedrock is pay per token. Time: 15 minutes.
Needs: nothing in a workspace. On a laptop, Claude Code and either AWS credentials for Bedrock or an OpenRouter key.

## Terms

- **Zero data retention:** the provider does not keep prompts or responses after answering. WRDS allows "protected" tools that do not train on your queries; this is the setting that aims at it.
- **Routing:** which company's servers the model runs on. Claude Code can send its requests to Amazon Bedrock or OpenRouter instead of Anthropic.
- **Hook:** a script that Claude Code runs around each tool call. The guard's hooks stop any row of data reaching the model.

The guard is one reading of the WRDS policy, not a ruling. Tell the participant to check it with their library or the vendor before using it with real data.

## 1. Get the guard

In a workspace the folder is already on the image:

```bash
cp -r /opt/wrds-guard ~/wrds-guard && cd ~/wrds-guard
```

If `/opt/wrds-guard` does not exist, or on a laptop, download it:

```bash
cd ~ && curl -fsSL https://christianengels.net/ai-workshop-2026-11/wrds-guard.zip -o wrds-guard.zip && unzip -q wrds-guard.zip && rm wrds-guard.zip && cd ~/wrds-guard
```

Check: `ls` shows `bin`, `data`, `src`, `tests` and `README.md`.

## 2. Run the unit tests

```bash
python3 -m unittest discover -s tests
```

Check: `OK (skipped=1)`. The skipped test needs `pyarrow` and is not needed.

## 3. Set the routing

Choose one. The participant runs these commands, because they involve a key.

**Workspace, through OpenRouter.** The workspace has the organiser's key in `OPENROUTER_API_KEY`. Open a new terminal, so that the regular Claude session in the other terminal is unaffected, and run, as one block:

```bash
cd ~/wrds-guard
export ANTHROPIC_BASE_URL=https://openrouter.ai/api
export ANTHROPIC_AUTH_TOKEN="$OPENROUTER_API_KEY"
export ANTHROPIC_API_KEY=""
export ANTHROPIC_DEFAULT_OPUS_MODEL="~anthropic/claude-opus-latest[1m]"
export ANTHROPIC_DEFAULT_SONNET_MODEL="~anthropic/claude-sonnet-latest[1m]"
export ANTHROPIC_DEFAULT_HAIKU_MODEL="~anthropic/claude-haiku-latest"
```

The shell fills in the key; it is never typed or shown. Zero retention is a setting of the OpenRouter account, not of the key, and the organiser has to have switched it on at openrouter.ai/settings/privacy. OpenRouter guarantees Claude Code only on Anthropic's own endpoint, which is not on its zero-retention list, so this route is a demonstration until it has been tested with the setting on.

**Laptop, through Bedrock.** Copy `.claude/settings.local.json.example` to `.claude/settings.local.json` and fill in the AWS profile, region and inference profile IDs. In the AWS account, `data_retention_mode` must be `none` for the region, and invocation logging off. Do not use `/setup-bedrock`: it writes Bedrock into the user settings, so it would apply to every project.

**Laptop, through OpenRouter.** The same exports as for the workspace, with the participant's own key in place of `$OPENROUTER_API_KEY`, and zero retention switched on in their account settings.

## 4. Start Claude

In the same terminal:

```bash
claude
```

Check: the first message from Claude mentions the WRDS guard and says how the session is routed: "Amazon Bedrock, region ..." or "openrouter.ai, through ANTHROPIC_BASE_URL". Then run `/status`: the provider line shows the same. If the routing is missing, every prompt is refused with a message that says what to set.

## 5. Try it

Put a CSV in `data/`, then ask:

```
Write src/01-summary.py that reads data/<file>.csv with the csv module and writes the mean of each numeric column to output/summary.csv, then run it.
```

Check: Claude reports a line such as `new: output/summary.csv · 3 data rows after the header · columns: ...` and says it cannot see the values. Ask it to show the first rows: it should refuse and offer a script. The participant reads `output/summary.csv` in the VS Code editor and copies what Claude may read into `approved/`.

## If it goes wrong

- `model routing is not configured` on the first prompt: the exports were run in a different terminal, or `claude` was started before them. Run step 3 again in the terminal where `claude` will start.
- `OPENROUTER_API_KEY` is empty (`echo ${#OPENROUTER_API_KEY}` prints `0`): the workspace has no key. Use a laptop route, or ask the organiser.
- `401` or `402` from OpenRouter: the key is wrong, or its credit limit is reached. Ask the organiser.
- A request fails with a message about the provider or endpoint: OpenRouter's zero-retention routing may be sending Claude Code to an endpoint it does not support. Stop and say so; do not switch zero retention off to make it work.
- A tool call says `blocked by hook` for everything, including `ls`: a hook file is missing or not executable. Run step 2; if the tests fail, download the guard again.
- Claude says it cannot see why a script failed: that is by design. It sees the error type and the line. The participant opens the log named in the summary, in `logs/guard/`, and tells Claude what it says, or Claude adds a check to the script.
