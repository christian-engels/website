# Make and view Quarto slides

Status: Partly validated, 5 November 2026, in a workshop workspace: the install, a render in 3 seconds and serving the page through the workspace's web proxy.
Not run: opening the printed address in Simple Browser. The workspace browser uses the same route.
Runs in: workspace or laptop. Cost: free. Time: 10 minutes. Disk: about 620 MB.

## Terms

- **Quarto:** a program that turns a text file into slides or documents.
- **`.qmd`:** a Quarto text file. **Render:** turn it into the finished page.

## 1. Create the project

```bash
cd ~/project
uv init slides
cd slides
uv add quarto-cli
```

## 2. Write the deck

Create `deck.qmd`:

````markdown
---
format:
  revealjs:
    width: 1280
    height: 720
    margin: 0.03
    center: false
    embed-resources: true
    code-copy: true
---

## First slide

- One point
````

## 3. Render it

```bash
uv run quarto render deck.qmd
```

Check: `Output created: deck.html`.

## 4. View it

Simple Browser in a workspace cannot open a local file, so serve the folder:

```bash
python3 -m http.server 8000 --bind 127.0.0.1
```

Leave that running. Then, in a second terminal, print the address:

```bash
echo "${CODER_AGENT_URL%/}/@${CODER_WORKSPACE_OWNER_NAME}/${CODER_WORKSPACE_NAME}.${CODER_WORKSPACE_AGENT_NAME:-main}/apps/code-server/proxy/8000/deck.html"
```

Open that address with **Simple Browser: Show**. To stop serving, press `Ctrl+C` in the first terminal.

On a laptop, open `deck.html` by double-clicking it. Or, in a workspace, right-click it in the Explorer and choose **Download...**.

## If it goes wrong

- `Address already in use`: something is using port 8000. Use `8001` in both commands.
- The page shows old content: render again and reload.
