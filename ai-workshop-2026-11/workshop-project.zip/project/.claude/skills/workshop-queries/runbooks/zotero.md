# Zotero Web API

Status: Not validated. Written from Zotero's documentation. Only the `pyzotero` install was run, on 5 November 2026. Say so and ask before you start.
Runs in: workspace or laptop. Cost: free; file storage above 300 MB is paid. Time: 10 minutes.

A workspace cannot reach the Zotero app on a laptop, so it uses Zotero's website instead.

## 1. Create a key

The participant does this at <https://www.zotero.org/settings/keys>:

1. Note the number shown as **Your user ID**
2. Choose **Create new private key**
3. Tick **Allow library access** and **Allow write access**
4. Save and copy the key

## 2. Add them to `.env`

`ZOTERO_API_KEY` and `ZOTERO_USER_ID`: see `api-keys.md`.

## 3. Test by reading, not writing

```bash
uv add pyzotero python-dotenv
```

Write a short script that loads `.env`, connects with `zotero.Zotero(user_id, "user", api_key)` and prints the number of items.

Check: the number matches the library.

## 4. Write

Ask before adding anything to the participant's library. Add to a new collection, not to the main library. Write up to 50 items at a time.

## If it goes wrong

- `403`: the key lacks write access, or the user ID is wrong.
