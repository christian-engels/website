# Overleaf through Git

Status: Not validated. Written from Overleaf's documentation; no test account had the feature. Say so and ask before you start.
Runs in: workspace or laptop. Cost: a paid Overleaf plan, group access or Overleaf Commons for the project owner. Time: 10 minutes.

## 1. Create a token

The participant creates a Git token in Overleaf's account settings, and stores it as `OVERLEAF_GIT_TOKEN` in `.env`. Tokens last one year.

## 2. Clone the project

The project's address is under **Menu → Git** in Overleaf.

```bash
git clone https://git.overleaf.com/<project-id> paper
```

The participant enters `git` as the username and the token as the password.

## 3. Work

Run `git pull` before you start and before you push. Keep the project under 100 MB.

Pushing can lose tracked changes and comments, so tell the participant before the first push if they share the project with co-authors. There is one branch only, with no tags or Git LFS.

## If it goes wrong

- `Authentication failed`: the username must be `git`, and the password must be the token.
