# AI Research Workshop: take-home materials

Universitat Jaume I, 6 November 2026. Christian Engels.

Open **index.html** in a browser. The five slide decks and all three guides work offline, including their images, fonts and diagrams. Links to outside websites and AI tools need an internet connection. In Coder, use the public workshop website; download this folder before the server is deleted on 7 November.

## What is here

| Path | Contents |
|:--|:--|
| `index.html` | Home page, session links and guides |
| `session-*.html` | All five slide decks |
| `basics.html`, `self-guided.html`, `own-machine.html` | Guides |
| `source/slides/` | All nine main `.qmd` files and seven diagram partials, themes, fonts, images, figure data and build tools |
| `project/` | Starter project and the `/workshop-queries` skill with its runbooks |
| `wrds-guard/` | Optional guarded project, launcher, hooks and tests |
| `workshop-data/` | Saved public teaching data for the morning exercises |
| `workshop-project.zip`, `wrds-guard.zip` | Separate downloads used by the guides |
| `manifest.json` | Source revision and SHA-256 checksums of every supplied file |

The starter is also supplied as a small ZIP. It does not contain a second copy of this package. In a new Coder workspace, this whole folder is already at `~/project/workshop-materials/` and is included when you push the project to your own GitHub repository. Your own working files and credentials are not part of the public download: save your work separately before leaving.

## Edit and rebuild

The `.qmd` files are plain text. You can read or edit them without installing Quarto. To rebuild the HTML, first install `uv` using the setup guide, open a terminal in `source/slides/`, then run:

```bash
uv sync --locked
uv run python scripts/12-render_materials.py ../../rebuilt
```

Open `rebuilt/index.html`. The first build downloads Python packages and Quarto, so it needs internet access. Generated HTML contains its own fonts and images. Edit the supplied files as you wish; `manifest.json` describes the original download and does not update itself.

The rendered figures and their aggregate data are included. Scripts 02–06 can recreate the workshop cost and energy figures. Raw session transcripts are private and are not included; the extraction scripts that require them are omitted. Empirical claims and provider-policy snapshots are dated and sourced in the slides; they are not promises about future models, prices or policies.

## Continue the exercises

Use your own Claude subscription with plain `claude`. The shared workshop OpenRouter key is optional, has a **$50 total limit for everyone**, permits **Haiku, Sonnet and Opus 5.5**, and expires **12 November 2026 at 15:43 UTC**. No API keys, account tokens or personal Claude history are in this package. Use your own key after the workshop, stored privately in `.env` or a password manager.

For the guard exercise, read `wrds-guard/README.md`, open a terminal in that folder, run its unit tests and `bin/claude-openrouter --check`, then launch with `bin/claude-openrouter`. Check the applicable data licence and guard limitations before using real licensed data. The supplied examples and tests use synthetic values.

The saved morning CSV files are compressed with gzip; R and Python can read them directly. See `workshop-data/README.md` for their origin. They provide a fallback for the specified exercise dates, rather than a current market feed.

## Credits

The workshop materials are by Christian Engels. Cited research, product names and university logos remain attributable to their original owners. Fira Sans and Fira Code are distributed under the SIL Open Font License; the licence files are in `source/slides/theme/fonts/`. Please retain citations and these font licences when sharing modified materials.
