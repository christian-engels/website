#!/usr/bin/env python3
"""Claude Code hooks for the WRDS guard.

One file, one subcommand per hook event. Each reads the hook's JSON from stdin and prints a decision as
JSON. The settings file wires them up with "onFailure": "block", so a hook that crashes, times out or
prints something unexpected blocks the call rather than letting it through.

    pre-bash       PreToolUse, Bash: deny inline code and consoles; wrap the rest in bin/guard
    pre-read       PreToolUse, Read/Grep/Glob/Edit/Write/NotebookEdit: keep file tools out of the data
    pre-mcp        PreToolUse, mcp__*: deny MCP tools that could return rows
    post-bash      PostToolUse, Bash: withhold output that still looks like a table
    prompt         UserPromptSubmit: refuse to work until the model is routed as agreed
    session-start  SessionStart: tell Claude the rules and the routing in force

Only the standard library is used, so the hooks run with any Python 3.9 or later.
"""

from __future__ import annotations

import json
import os
import re
import shlex
import sys
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[2]
GUARD = ROOT / "bin" / "guard"
CONFIG = json.loads((ROOT / ".claude" / "guard.json").read_text())

DENIED_DIRS = [ROOT / d for d in CONFIG["denied_dirs"]]
DATA_EXT = {e.lower() for e in CONFIG["data_extensions"]}
CODE_EXT = {e.lower() for e in CONFIG["code_extensions"]}
ALLOWED = [tuple(c.split()) for c in CONFIG["allowed_commands"]]

# Programs whose "run this string" flags turn a command into inline code.
INLINE_FLAGS = {
    "python": {"-c", "-i", "-m"}, "ipython": {"-c", "-i"}, "pypy": {"-c"}, "pypy3": {"-c"},
    "Rscript": {"-e"}, "R": {"-e"}, "node": {"-e", "-p", "-i"}, "perl": {"-e", "-E"},
    "ruby": {"-e"}, "julia": {"-e", "-E"}, "php": {"-r"}, "lua": {"-e"},
    "bash": {"-c"}, "sh": {"-c"}, "zsh": {"-c"}, "dash": {"-c"}, "ksh": {"-c"}, "fish": {"-c"},
    "pwsh": {"-c", "-Command"}, "osascript": {"-e"},
}
# Programs that open a console when given no file to run.
CONSOLES = set(INLINE_FLAGS) | {"stata", "stata-mp", "stata-se", "StataMP", "StataSE", "sas", "matlab", "octave"}
# Database clients print query results; a script in src/ writes them to output/ instead.
DB_CLIENTS = {"psql", "sqlite3", "duckdb", "mysql", "mariadb", "mongosh", "mongo", "clickhouse", "clickhouse-client",
              "bq", "snowsql", "sqlcmd", "usql", "litecli", "pgcli", "mycli"}
# Viewers and filters that print file contents.
VIEWERS = {"cat", "head", "tail", "less", "more", "most", "column", "xxd", "od", "hexdump", "strings", "bat", "nl",
           "tac", "rev", "cut", "paste", "sort", "uniq", "awk", "gawk", "mawk", "nawk", "sed", "grep", "egrep",
           "fgrep", "rg", "ag", "ack", "zcat", "gzcat", "zless", "zmore", "bzcat", "xzcat", "jq", "yq", "csvlook",
           "csvcut", "csvstat", "csvgrep", "csvsql", "in2csv", "xsv", "qsv", "mlr", "miller", "vd", "visidata",
           "tabview", "sqlite-utils", "parquet-tools", "pqrs", "dasel", "fold", "fmt", "pr", "expand", "unexpand",
           "iconv", "dos2unix", "tee", "cp", "scp", "rsync", "curl", "wget", "base64", "gzip", "gunzip", "zip",
           "unzip", "tar", "open", "xdg-open", "code", "vim", "vi", "nano", "emacs"}
ALWAYS_DENIED = {"eval", "source", ".", "sudo", "doas", "su", "exec"} | DB_CLIENTS
# Commands that print names, sizes or nothing, never contents, so a data path as argument is fine.
NAMES_ONLY = {"ls", "cd", "pwd", "mkdir", "tree", "test", "touch", "which", "stat", "du", "file", "wc"}
WRAPPERS = {"env", "command", "builtin", "time", "nice", "nohup", "stdbuf", "xargs", "caffeinate", "noglob"}
OPERATORS = {";", "|", "||", "&&", "&", "(", ")", "|&", "{", "}"}
REDIRECTS = {"<", ">", ">>", "<>", "&>", ">&", "&>>", "<<<", "2>", "1>"}
GLOB_CHARS = re.compile(r"[*?\[\]{}]")


# ---- Plumbing ------------------------------------------------------------------------------------

def read_input() -> dict:
    raw = sys.stdin.read()
    return json.loads(raw) if raw.strip() else {}


def emit(obj: dict) -> None:
    print(json.dumps(obj))
    sys.exit(0)


def pre_decision(decision: str | None, reason: str | None = None, updated_input: dict | None = None) -> None:
    out: dict = {"hookEventName": "PreToolUse"}
    if decision:
        out["permissionDecision"] = decision
        out["permissionDecisionReason"] = reason or ""
    if updated_input is not None:
        out["updatedInput"] = updated_input
    emit({"hookSpecificOutput": out})


def deny(reason: str) -> None:
    pre_decision("deny", "WRDS guard: " + reason)


def passthrough() -> None:
    emit({})


# ---- Paths and content ---------------------------------------------------------------------------

def strip_glob(token: str) -> str:
    """The literal prefix of a path that may contain glob characters."""
    m = GLOB_CHARS.search(token)
    return token[: m.start()] if m else token


def extension(token: str) -> str:
    name = os.path.basename(token.rstrip("/"))
    return os.path.splitext(name)[1].lower()


def resolve(token: str, cwd: str) -> Path:
    tok = os.path.expanduser(token)
    p = Path(tok)
    if not p.is_absolute():
        p = Path(cwd) / p
    try:
        return p.resolve()
    except (OSError, RuntimeError):
        return p


def under_denied_dir(path: Path) -> bool:
    for d in DENIED_DIRS:
        try:
            if path == d or path.is_relative_to(d):
                return True
        except ValueError:
            pass
    return False


def names_denied_dir(token: str) -> bool:
    """A relative token that walks through a denied folder name, however the path is anchored."""
    parts = [p for p in token.replace("\\", "/").split("/") if p not in ("", ".")]
    denied_names = {d.name for d in DENIED_DIRS}
    return any(p in denied_names for p in parts[:-1]) or (len(parts) == 1 and parts[0] in denied_names)


def token_is_data(token: str, cwd: str) -> bool:
    """True when a command-line token refers to a data folder or a data file."""
    if not token:
        return False
    tok = token.split("=", 1)[1] if re.match(r"^--?[\w-]+=", token) else token  # --input=data/x.csv
    if tok.startswith("-"):
        return False
    tok = tok.split(":", 1)[1] if re.match(r"^[\w.~/-]*:(\./)?(data|output|logs)/", tok) else tok  # HEAD:data/x
    if extension(strip_glob(tok)) in DATA_EXT or extension(tok) in DATA_EXT:
        return True
    if "/" in tok or tok in {d.name for d in DENIED_DIRS}:
        if names_denied_dir(tok) and not os.path.isabs(tok):
            return True
        return under_denied_dir(resolve(strip_glob(tok), cwd))
    return False


MAGIC = [
    (b"PAR1", "a Parquet file"), (b"ARROW1", "an Arrow file"), (b"SQLite format 3", "an SQLite database"),
    (b"\x1f\x8b", "a gzip file"), (b"PK\x03\x04", "a zip or Excel file"), (b"<stata_dta>", "a Stata file"),
    (b"RDX2\n", "an R data file"), (b"RDX3\n", "an R data file"), (b"\x89HDF\r\n\x1a\n", "an HDF5 file"),
    (b"\x93NUMPY", "a NumPy array"), (b"\x80\x04", "a Python pickle"), (b"\x80\x05", "a Python pickle"),
]


def looks_tabular(text: str) -> bool:
    """Several consecutive lines with the same number of delimiters, or whitespace columns of numbers."""
    lines = [ln for ln in text.splitlines() if ln.strip()][:40]
    if len(lines) < 4:
        return False
    for delim in (",", "\t", ";", "|"):
        counts = [ln.count(delim) for ln in lines]
        if counts[0] >= 1 and len(set(counts)) == 1:
            return True
    fields = [ln.split() for ln in lines]
    widths = {len(f) for f in fields}
    if len(widths) == 1 and widths.pop() >= 2:
        cells = [c for f in fields for c in f]
        numeric = sum(bool(re.fullmatch(r"[-+]?\d[\d,]*(\.\d+)?(e[-+]?\d+)?%?", c, re.I)) for c in cells)
        if numeric >= len(cells) / 2:
            return True
    return False


def sniff_file(path: Path) -> str | None:
    """A reason to deny reading this file, from its first bytes, or None."""
    try:
        with open(path, "rb") as fh:
            head = fh.read(4096)
    except OSError:
        return None
    for magic, what in MAGIC:
        if head.startswith(magic):
            return f"{path.name} is {what}"
    if path.suffix.lower() in CODE_EXT:
        return None
    try:
        text = head.decode("utf-8")
    except UnicodeDecodeError:
        return f"{path.name} is a binary file of unknown type"
    if looks_tabular(text):
        return f"{path.name} looks like a table"
    return None


# ---- pre-bash --------------------------------------------------------------------------------------

def lex(command: str) -> list[str]:
    lexer = shlex.shlex(command, posix=True, punctuation_chars=True)
    lexer.whitespace_split = True
    return list(lexer)


def split_simple(tokens: list[str]) -> list[list[str]]:
    """Split a token stream into simple commands, dropping operators and redirection targets."""
    commands: list[list[str]] = [[]]
    skip = False
    for tok in tokens:
        if skip:
            skip = False
            commands[-1].append(tok)  # the redirect target still counts as a data check
            continue
        if tok in OPERATORS:
            if commands[-1]:
                commands.append([])
            continue
        if tok in REDIRECTS or re.fullmatch(r"\d*[<>]{1,2}&?\d*", tok):
            skip = not re.fullmatch(r"\d*>&\d+", tok)
            continue
        commands[-1].append(tok)
    return [c for c in commands if c]


def unwrap(words: list[str]) -> list[str]:
    """Strip VAR=value assignments, wrappers such as timeout and env, and `uv run`."""
    i = 0
    while i < len(words):
        w = words[i]
        if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*=.*", w):
            i += 1
        elif w in WRAPPERS:
            i += 1
            while i < len(words) and words[i].startswith("-"):
                i += 1
        elif w == "timeout":
            i += 1
            while i < len(words) and (words[i].startswith("-") or re.fullmatch(r"\d+[smhd]?", words[i])):
                i += 1
        elif w in ("uv", "uvx", "poetry", "pipx", "pdm", "hatch", "conda", "micromamba", "npx", "bunx"):
            if w in ("uv", "poetry", "pdm", "hatch", "conda", "micromamba") and i + 1 < len(words) and words[i + 1] == "run":
                i += 2
                while i < len(words) and words[i].startswith("-"):
                    if words[i] in ("--project", "--directory", "--with", "--python", "-p", "-n", "--name",
                                    "--group", "--extra", "--env-file", "--with-requirements"):
                        i += 1
                    i += 1
            elif w in ("uvx", "pipx", "npx", "bunx"):
                i += 1
                while i < len(words) and words[i].startswith("-"):
                    i += 1
            else:
                break
        else:
            break
    return words[i:]


def program_name(word: str) -> str:
    base = os.path.basename(word)
    if re.fullmatch(r"python[0-9.]*", base):
        return "python"
    return base


def check_simple(words: list[str], cwd: str) -> tuple[str, str | None]:
    """Classify one simple command: ('deny', reason), ('pass', None) or ('guard', None)."""
    if not words:
        return "pass", None
    if words[0] == "exec":
        return "deny", "`exec` replaces the shell; run the program directly"
    inner = unwrap(words)
    if not inner:
        return "pass", None  # a bare assignment such as X=1
    prog = program_name(inner[0])
    args = inner[1:]
    data_args = [a for a in args if token_is_data(a, cwd)]

    if prog in ALWAYS_DENIED or prog in DB_CLIENTS:
        if prog in DB_CLIENTS:
            return "deny", f"`{prog}` prints query results; put the query in a script in src/ that writes to output/"
        return "deny", f"`{prog}` is not allowed here"
    if prog in INLINE_FLAGS:
        flags = INLINE_FLAGS[prog]
        if prog == "python" and "-m" in args:
            # python -m module is a program, not inline code, unless it is a console
            mod = args[args.index("-m") + 1] if args.index("-m") + 1 < len(args) else ""
            if mod in ("code", "IPython", "pdb", "idlelib", "asyncio"):
                return "deny", f"`python -m {mod}` opens a console"
            flags = flags - {"-m"}
        if any(a in flags for a in args):
            return "deny", f"inline code (`{prog} {sorted(set(args) & flags)[0]}`) is not allowed; save it as a script in src/"
        positional = [a for a in args if not a.startswith("-")]
        if prog in ("bash", "sh", "zsh", "dash", "ksh", "fish") and "-s" in args:
            return "deny", f"`{prog} -s` reads a script from standard input"
        if "-" in args or not positional:
            if prog == "R" and any(a in ("CMD", "--file") or a.startswith("--file=") for a in args):
                pass
            else:
                return "deny", f"`{prog}` with no script opens a console or reads code from standard input"
    elif prog in CONSOLES:
        positional = [a for a in args if not a.startswith("-")]
        if not positional:
            return "deny", f"`{prog}` with no script opens a console"
    if prog in VIEWERS and data_args:
        return "deny", f"`{prog}` on {data_args[0]}: data files are off limits to Claude. Write a script in src/ that saves results to output/"
    if prog in ("rm", "rmdir", "mv", "shred", "truncate") and data_args:
        return "deny", f"`{prog}` on {data_args[0]}: raw data stays as it is"
    if data_args and prog not in NAMES_ONLY:
        return "guard", None
    if prog == "git" and args:
        key = ("git", args[0])
        if key in ALLOWED and args[0] != "show":
            return "pass", None
        return "guard", None
    if (prog,) in ALLOWED or (prog, *args[:1]) in ALLOWED:
        return "pass", None
    return "guard", None


def guard_inner(command: str, cwd: str) -> str | None:
    """If the command is a call to bin/guard, the command guard would run; otherwise None."""
    try:
        words = lex(command)
    except ValueError:
        return None
    if not words or program_name(words[0]) != "guard" or resolve(words[0], cwd) != GUARD:
        return None
    if any(w in OPERATORS for w in words):
        return None  # guard as one part of a pipeline: treat the whole line normally
    args = words[1:]
    if args and args[0] == "-c":
        return " ".join(args[1:])
    return shlex.join(args)


def pre_bash(data: dict) -> None:
    tool_input = data.get("tool_input") or {}
    command = tool_input.get("command") or ""
    cwd = data.get("cwd") or os.getcwd()
    if not command.strip():
        passthrough()
    inner = guard_inner(command, cwd)
    if inner is not None:
        command = inner  # Claude called guard itself: check what it asked guard to run, then leave it as it is
    for needle, what in (("$(", "command substitution `$( )`"), ("`", "backticks"), ("<(", "process substitution"),
                         (">(", "process substitution"), ("<<", "a here-document")):
        if needle in command:
            deny(f"{what} is not allowed, because its output is not logged; write the steps out plainly")
    try:
        tokens = lex(command.replace("\n", " ; "))
    except ValueError as exc:
        deny(f"the command does not parse ({exc}); fix the quoting")
    simple = split_simple(tokens)
    verdicts = [check_simple(words, cwd) for words in simple]
    for verdict, reason in verdicts:
        if verdict == "deny":
            deny(reason or "not allowed")
    if inner is not None or all(v == "pass" for v, _ in verdicts):
        passthrough()
    updated = dict(tool_input)
    updated["command"] = f"{shlex.quote(str(GUARD))} -c {shlex.quote(command)}"
    pre_decision(None, updated_input=updated)


# ---- pre-read --------------------------------------------------------------------------------------

def pre_read(data: dict) -> None:
    tool = data.get("tool_name") or ""
    tool_input = data.get("tool_input") or {}
    cwd = data.get("cwd") or os.getcwd()
    raw = tool_input.get("file_path") or tool_input.get("notebook_path") or tool_input.get("path") or cwd
    path = resolve(str(raw), cwd)
    if under_denied_dir(path):
        deny(f"{tool} in {path.relative_to(ROOT) if path.is_relative_to(ROOT) else path}: this folder is off limits to Claude")
    if tool in ("Read", "Edit", "Write", "NotebookEdit"):
        if extension(path.name) in DATA_EXT:
            deny(f"{path.name} is a data file; Claude sees names, types and counts only")
        if tool == "Read" and path.is_file():
            reason = sniff_file(path)
            if reason:
                deny(reason + "; Claude sees names, types and counts only")
        if tool == "Read" and path.is_symlink():
            deny(f"{path.name} is a symbolic link")
    if tool in ("Grep", "Glob"):
        pattern = str(tool_input.get("pattern") or "")
        glob = str(tool_input.get("glob") or "")
        for pat in (pattern if tool == "Glob" else "", glob):
            if pat and (names_denied_dir(pat) or extension(strip_glob(pat)) in DATA_EXT
                        or any(pat.lower().endswith(e) for e in DATA_EXT)):
                deny(f"{tool} pattern `{pat}` reaches data files")
    passthrough()


# ---- pre-mcp ---------------------------------------------------------------------------------------

def pre_mcp(data: dict) -> None:
    tool = data.get("tool_name") or ""
    m = re.match(r"mcp__(.+?)__(.+)", tool)
    if not m:
        passthrough()
    server = m.group(1)
    if server in CONFIG.get("mcp_allowed_servers", []):
        passthrough()
    deny(f"MCP server `{server}` is not on the allowed list in .claude/guard.json, because its tools can return rows")


# ---- post-bash -------------------------------------------------------------------------------------

def post_bash(data: dict) -> None:
    tool_input = data.get("tool_input") or {}
    response = data.get("tool_response")
    command = tool_input.get("command") or ""
    if not isinstance(response, dict) or command.lstrip().startswith(str(GUARD)):
        passthrough()
    replaced = dict(response)
    changed = False
    for key in ("stdout", "stderr"):
        text = response.get(key)
        if isinstance(text, str) and looks_tabular(text):
            n = len(text.splitlines())
            replaced[key] = (f"[WRDS guard withheld {n:,} lines of {key}: they looked like a table. "
                             "Save results to output/ and ask the researcher to review them.]")
            changed = True
    if not changed:
        passthrough()
    emit({"hookSpecificOutput": {"hookEventName": "PostToolUse", "updatedToolOutput": replaced}})


# ---- prompt and session-start ------------------------------------------------------------------------

def routing() -> tuple[bool, str]:
    env = os.environ
    if any(env.get(k, "").lower() in ("1", "true") for k in
           ("CLAUDE_CODE_USE_BEDROCK", "CLAUDE_CODE_USE_VERTEX", "CLAUDE_CODE_USE_FOUNDRY")):
        return False, "a direct cloud-provider override is set; launch with bin/claude-openrouter"
    base = env.get("ANTHROPIC_BASE_URL", "")
    parsed = urlparse(base)
    host = parsed.hostname or ""
    for allowed in CONFIG.get("allowed_base_url_hosts", []):
        if parsed.scheme == "https" and host == allowed and not parsed.username and not parsed.password:
            return True, f"{host}, through ANTHROPIC_BASE_URL"
    return False, "not configured: the session would use Anthropic's consumer or API endpoint"


def prompt(data: dict) -> None:
    ok, where = routing()
    if CONFIG.get("require_routing", True) and not ok:
        emit({"decision": "block",
              "reason": ("WRDS guard: model routing is " + where + ". Exit and run bin/claude-openrouter "
                         "from this project. Keep the routing check and hooks enabled.")})
    passthrough()


def session_start(data: dict) -> None:
    ok, where = routing()
    denied = ", ".join(d.name + "/" for d in DENIED_DIRS)
    context = (
        "WRDS guard is active in this project.\n"
        f"- Model routing: {where}.\n"
        f"- The folders {denied} hold licensed data and are off limits: you see column names, types and row counts only.\n"
        "- Run shell commands as usual: a hook wraps each one in bin/guard, which logs the output to logs/guard/ "
        "and shows you a summary: exit code, line counts, and the shape of new files in output/. On failure you "
        "see the error type and line, not the message. Write scripts in src/ that save results to output/.\n"
        "- The researcher reviews output/ and copies what you may read into approved/.\n"
        "- Inline code (python -c, Rscript -e), consoles, database clients and MCP tools that return rows are denied."
    )
    emit({"hookSpecificOutput": {"hookEventName": "SessionStart", "additionalContext": context}})


HANDLERS = {"pre-bash": pre_bash, "pre-read": pre_read, "pre-mcp": pre_mcp, "post-bash": post_bash,
            "prompt": prompt, "session-start": session_start}


def main() -> None:
    if len(sys.argv) != 2 or sys.argv[1] not in HANDLERS:
        print(f"usage: guardhooks.py {{{'|'.join(HANDLERS)}}}", file=sys.stderr)
        sys.exit(2)
    if sys.argv[1] in os.environ.get("WRDS_GUARD_BREAK", "").split(","):
        print("WRDS guard: this hook is broken on purpose (WRDS_GUARD_BREAK)", file=sys.stderr)
        sys.exit(1)  # the fail-closed test: with onFailure block, the call must not go ahead
    HANDLERS[sys.argv[1]](read_input())


if __name__ == "__main__":
    main()
