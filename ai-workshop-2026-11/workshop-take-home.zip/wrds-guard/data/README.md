# data/

Raw and derived data. Claude's tools cannot read this folder: a deny rule and a hook stop them, and
shell commands that name a file here are refused or run through `bin/guard`.
