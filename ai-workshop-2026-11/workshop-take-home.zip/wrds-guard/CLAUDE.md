# WRDS guard

This project holds licensed data that must not reach a language model. Hooks enforce this; these notes say
how to work within them.

- `data/`, `output/` and `logs/` are off limits. You see column names, types and row counts, never values.
- Write scripts in `src/` that read from `data/` and save results to `output/`. Do not print data.
- Run commands as usual. A hook wraps each one in `bin/guard`, which logs the output and shows you a summary:
  exit code, line counts, and the shape of new files. On failure you see the error type and `file:line`.
- To find out what went wrong, add checks to the script that fail with a clear exception type, or ask the
  researcher to read the log named in the summary.
- The researcher reviews `output/` and copies what you may read into `approved/`.
- Inline code (`python -c`, `Rscript -e`), consoles, database clients and MCP servers that return rows are
  denied. Do not try to work around a denial; say what was denied and why, and suggest a script instead.
