"""Offline checks: launcher isolation and fail-closed setup, with a fake Claude binary."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

SOURCE = Path(__file__).resolve().parents[1]


class Launcher(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.home = Path(self.temp.name)
        self.root = self.home / "project with spaces"
        for rel in ("bin/claude-openrouter", "bin/guard", ".claude/guard.json", ".claude/settings.json",
                    ".claude/hooks/guardhooks.py"):
            target = self.root / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(SOURCE / rel, target)
        self.commands = self.home / "commands"
        self.commands.mkdir()
        fake = self.commands / "claude"
        fake.write_text(f"#!{sys.executable}\nimport os,json,sys\nprint(json.dumps({{'env':dict(os.environ),'args':sys.argv[1:],'cwd':os.getcwd()}}))\n")
        fake.chmod(0o700)
        self.env = {**os.environ, "HOME": str(self.home), "PATH": str(self.commands) + os.pathsep + os.environ["PATH"],
                    "OPENROUTER_API_KEY": "synthetic-test-key", "CLAUDE_CODE_OAUTH_TOKEN": "synthetic-subscription-token",
                    "CLAUDE_CODE_USE_BEDROCK": "1", "CLAUDE_CODE_USE_VERTEX": "1", "ANTHROPIC_API_KEY": "old-key"}

    def run_launcher(self, *args):
        return subprocess.run([sys.executable, str(self.root / "bin/claude-openrouter"), *args],
                              env=self.env, capture_output=True, text=True, timeout=15)

    def test_routes_child_without_modifying_subscription(self):
        account = self.home / ".claude/.credentials.json"
        account.parent.mkdir()
        account.write_text("subscription-sentinel")
        p = self.run_launcher("--model", "sonnet", "--continue")
        self.assertEqual(p.returncode, 0, p.stderr)
        d = json.loads(p.stdout)
        self.assertEqual(Path(d["cwd"]).resolve(), self.root.resolve())
        self.assertEqual(d["env"]["ANTHROPIC_BASE_URL"], "https://openrouter.ai/api")
        self.assertEqual(d["env"]["ANTHROPIC_API_KEY"], "")
        self.assertEqual(d["env"]["ANTHROPIC_AUTH_TOKEN"], "synthetic-test-key")
        self.assertEqual(d["env"]["ANTHROPIC_DEFAULT_SONNET_MODEL"], "anthropic/claude-sonnet-5.5")
        self.assertNotIn("CLAUDE_CODE_OAUTH_TOKEN", d["env"])
        self.assertNotIn("CLAUDE_CODE_USE_BEDROCK", d["env"])
        self.assertNotIn("CLAUDE_CODE_USE_VERTEX", d["env"])
        self.assertEqual(d["env"]["CLAUDE_CONFIG_DIR"], str(self.home / ".claude-openrouter"))
        self.assertEqual(d["args"][-3:], ["--model", "sonnet", "--continue"])
        self.assertEqual(len(json.loads(d["args"][1])["availableModels"]), 3)
        self.assertNotIn("synthetic-test-key", " ".join(d["args"]))
        self.assertEqual(account.read_text(), "subscription-sentinel")

    def test_missing_key_stops_before_launch(self):
        self.env.pop("OPENROUTER_API_KEY")
        p = self.run_launcher()
        self.assertNotEqual(p.returncode, 0)
        self.assertEqual(p.stdout, "")

    def test_missing_hook_stops_before_launch(self):
        (self.root / ".claude/hooks/guardhooks.py").unlink()
        self.assertNotEqual(self.run_launcher().returncode, 0)

    def test_disabled_routing_stops_before_launch(self):
        path = self.root / ".claude/guard.json"
        config = json.loads(path.read_text()); config["require_routing"] = False
        path.write_text(json.dumps(config))
        self.assertNotEqual(self.run_launcher().returncode, 0)

    def test_failed_open_hook_stops_before_launch(self):
        path = self.root / ".claude/settings.json"
        settings = json.loads(path.read_text())
        settings["hooks"]["PreToolUse"][0]["hooks"][0].pop("onFailure")
        path.write_text(json.dumps(settings))
        self.assertNotEqual(self.run_launcher().returncode, 0)

    def test_check_never_prints_key_or_starts_claude(self):
        p = self.run_launcher("--check")
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertIn("Ready:", p.stdout)
        self.assertNotIn("synthetic-test-key", p.stdout + p.stderr)


if __name__ == "__main__":
    unittest.main()
