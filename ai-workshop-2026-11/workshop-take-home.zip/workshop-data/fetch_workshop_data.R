# Fallback copies of the morning's data, baked into the image at /opt/workshop-data/
# in case Yahoo Finance throttles 80 simultaneous downloads from one server.
# Run inside a workspace: Rscript fetch_workshop_data.R  (writes to ./workshop-data/)
suppressMessages({library(tidyverse); library(tidyfinance)})
dir.create("workshop-data", showWarnings = FALSE)

dow <- download_data(domain = "Index Constituents", index = "Dow Jones Industrial Average")
write_csv(dow, "workshop-data/dow_constituents.csv")

prices_dow <- download_data(domain = "Stock Prices", symbols = dow$symbol,
                            start_date = "2000-01-01", end_date = "2024-12-31")
stopifnot(n_distinct(prices_dow$symbol) == nrow(dow))
write_csv(prices_dow, "workshop-data/dow_prices_2000_2024.csv.gz")

prices_ibex <- download_data(domain = "Stock Prices",
                             symbols = c("SAN.MC", "BBVA.MC", "ITX.MC", "IBE.MC"),
                             start_date = "2015-01-01", end_date = "2024-12-31")
write_csv(prices_ibex, "workshop-data/ibex_selected_prices_2015_2024.csv.gz")

cat("Dow:", nrow(prices_dow), "rows,", n_distinct(prices_dow$symbol), "firms; IBEX:", nrow(prices_ibex), "rows\n")
