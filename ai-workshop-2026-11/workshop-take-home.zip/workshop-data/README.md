# Saved data for the morning exercises

These files were prepared on 3 November 2026 with the adjacent `fetch_workshop_data.R` script, using Tidy Finance/Tidyquant and Yahoo Finance. They contain public market observations used in the workshop, not WRDS data. Index membership is a snapshot used for teaching, not a historical constituent series.

- `dow_constituents.csv`: 30 Dow Jones constituents used in the exercise.
- `dow_prices_2000_2024.csv.gz`: 184,323 price observations, including the Apple exercise (6,289 observations). Date range: 2000–2024; some companies start later.
- `ibex_selected_prices_2015_2024.csv.gz`: selected IBEX firms, 2015–2024; 2,560 observations per ticker in this saved snapshot.

R's `readr::read_csv()` and Python's `polars.read_csv()` read `.csv.gz` files directly. When a prompt refers to `/opt/workshop-data/`, substitute this folder's path on your laptop. Keep the original files unchanged and save transformations in your project. Prices and corporate-action adjustments may differ if downloaded again later.
