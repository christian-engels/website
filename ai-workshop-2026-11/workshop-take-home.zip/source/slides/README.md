# Workshop slides and site

Five Quarto reveal.js decks and four site pages for 6 November 2026:

- `01-claude-code.qmd`: Session 1a (10:00–11:00), first steps with Claude Code. Workspace, terminal, how an
  agent works, `CLAUDE.md`, plan and permission modes, context; a Tidy Finance task (Apple, then the Dow Jones).
- `01b-skills-subagents-mcp.qmd`: Session 1b (11:30–12:30), skills, three referee subagents and MCP servers.
- `02-agentic-ai.qmd`: Session 2 (12:30–13:30), understanding agentic AI and using it responsibly. Tokens and
  the agent loop, evidence on agents in research, prices and session cost, retention regimes, licensed data
  and the WRDS guard, energy, copyright and journal disclosure.
- `03-your-own-research.qmd`: Session 3 (15:00–16:00), finding papers, reading, analysis, writing, refereeing.
- `04-experimentation.qmd`: Session 4 (16:00–17:00), the self-guided tracks and keeping your work.
- `site-index.qmd`, `site-basics.qmd`, `site-self-guided.qmd`, `site-own-machine.qmd`: the home page and the
  three guides. `scripts/07-publish_site.sh` renders everything and copies it into the website checkout.

Render (Quarto comes from the project's uv environment; output is self-contained HTML, fonts included):

    uv run quarto render          # -> _output/01-claude-code.html, _output/02-agentic-ai.html

Press `S` in the browser for speaker notes, `F` for full screen.

Check that no slide overflows its frame (needs Playwright's Chromium: `uv run playwright install chromium`
once, or set `PW_CHROMIUM` to a Chromium binary):

    uv run python scripts/09-check_slides.py           # all decks; exit code 1 if any slide overflows
    uv run python scripts/09-check_slides.py 02 --shots  # one deck, with a PNG of each slide in _output/shots/

## Design

Audience: economics and finance academics, teaching register (clarity first, worked examples, hands-on).
UJI navy (#003764) and the teal of its symbol, as in `agenda.tex`; Fira Sans and Fira Code (bundled, OFL).
One title treatment (navy left rule); full-bleed navy section dividers and closing lines; amber marks
everything participants type or check. Titles are claims: read in sequence they give the argument.

Animated diagrams: inline SVG in `theme/diagrams/`, one `.qmd` partial each, pulled in with `{{< include >}}`
and animated with SMIL, so the decks stay single files with no library. `theme/nav.html` restarts a diagram when
its slide is shown and holds it at the end state (`data-end`) under reduced motion and in print. Seven so far:
the agent loop and the context window (1a), subagents and MCP (1b), next-token writing, the request-model-tools
flow and the guard's data flow (2). `scripts/10-check_diagrams.py` confirms each one moves, and `--still` that
each one freezes.

Closing lines, on a navy slide before the break: deck 1a, "The agent does the typing. You decide what to ask
and you check what it did." Deck 2, "Use agents for work you can check."

## Numbers and where they come from

The workshop-session figures use the data and scripts below. Empirical findings and policy claims cite their sources on the slides:

| Script | Output | Source |
|---|---|---|
| `01-extract_session_usage.py` | `data/session_usage_by_call.csv` | the local Claude Code transcript of the session that built the server, cut at 11:17:47 UTC on 3 Nov 2026 (114 calls) |
| `02-figure_context_per_call.py` | `figures/context_per_call.png` | the CSV |
| `03-figure_session_cost_by_model.py` | `figures/session_cost_by_model.png` | the CSV and OpenRouter list prices (`data/openrouter_models_2026-11-03.json`) |
| `04-figure_session_shares.py` | `figures/session_shares.png` | the CSV, Opus 5.5 prices, claude-footprint energy factors |
| `05-figure_energy_scale.py` | `figures/energy_scale.png` | the CSV, the claude-footprint method and published estimates (factors and citations in the script) |
| `06-figure_provider_policies.py` | `figures/provider_policies.png` | `data/openrouter_provider_policies_2026-11-03.csv`, transcribed from OpenRouter's provider table |
| `08-extract_rebuild_usage.py` | `data/rebuild_usage_by_call.csv` | the local transcript of the session that rebuilt deck 2 on 5 Nov 2026, with its subagent |

Figures from papers, reports and vendor pages in deck 2 were checked at source. The search and the checks are in
`../literature-search-map_session-2.md` and `../literature-search-log_session-2.md`. The WRDS setup in deck 2 is
built and tested in `../wrds-guard/`; the results on the slide "What the sessions did" come from its `tests/e2e.sh`.

Screenshots in `images/` were taken in Chrome on 3 Nov 2026 (OpenRouter settings and the Claude Sonnet 5.5
providers tab, cropped to exclude account details). `data/openrouter_zdr_endpoints_2026-11-03.json` is the
public list at openrouter.ai/api/v1/endpoints/zdr (1,090 endpoints), kept for reference.

Hands-on check values (6,289 Apple prices; 30 Dow firms and 184,323 prices; 2,560 days per IBEX ticker;
late starts for Salesforce, Alphabet and Visa) were verified by running the code in a workspace on 3 Nov 2026.
The same data are baked into the workspace image at `/opt/workshop-data/` as a fallback.

## Take-home package

`bash scripts/07-publish_site.sh <website-checkout>` renders the nine pages and runs the package builder. It creates `workshop-take-home.zip` in the website checkout and `~/.cache/ai-research-workshop/workshop-materials/` (or the matching `XDG_CACHE_HOME` folder). The image copies that folder into every new starter project; `workshop-refresh` adds a separate copy to an older home without replacing local edits. Stage the generated folder as `coder/image/workshop-materials/` (or `/root/image/workshop-materials/` on the host) before building.

The builder uses explicit public source directories, only referenced screenshots, tracked guard files, and three saved morning CSV files. It excludes environment files, Git history, raw session logs and private deployment configuration. A manifest records each file hash and the source revision. The font licences are included. Commit the sources before making the release package so `source_tree_dirty` is false. Keep staging outside Dropbox or other synchronised folders: they can restore conflicting generated copies during a build. The `--stage` argument overrides the cache location.

Rebuild just the linked HTML: `uv run python scripts/12-render_materials.py <output-directory>`. This same command works from the extracted package's `source/slides/` directory.
