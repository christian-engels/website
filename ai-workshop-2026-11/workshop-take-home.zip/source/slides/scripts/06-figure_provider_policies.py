"""How long the inference providers on OpenRouter keep your prompts.

Input: data/openrouter_provider_policies_2026-11-03.csv, transcribed from the provider table at
openrouter.ai/docs/guides/privacy/provider-logging on 3 November 2026 (96 providers).
These are provider defaults; a given endpoint can differ (check the shield on the model page).
Output: figures/provider_policies.png
"""

from pathlib import Path

import polars as pl
from plotnine import (aes, coord_flip, element_blank, element_rect, element_text, geom_col, geom_text, ggplot,
                      labs, scale_fill_manual, scale_x_discrete, scale_y_continuous, theme, theme_minimal)

ROOT = Path(__file__).resolve().parents[1]
GREEN, NAVY, GREY, RED, INK, PAPER = "#2E7D4F", "#003764", "#8A929C", "#B3261E", "#16202A", "#FBFAF7"
LABELS = {
    "Zero retention": "Keep nothing",
    "Retained for 30 days": "Keep 30 days",
    "Retained for 55 days": "Keep 55 days",
    "Prompts are retained for unknown period": "Keep for an unstated period",
}

policies = pl.read_csv(ROOT / "data" / "openrouter_provider_policies_2026-11-03.csv")
assert policies.height == 96 and set(policies["data_retention"]) <= set(LABELS)
counts = (
    policies.group_by("data_retention")
    .agg(n=pl.len(), may_train=(pl.col("train_on_prompts") == "May train").sum())
    .with_columns(policy=pl.col("data_retention").replace_strict(LABELS))
    .with_columns(label=pl.when(pl.col("may_train") > 0)
                  .then(pl.format("{}   ({} may train on prompts)", pl.col("n"), pl.col("may_train")))
                  .otherwise(pl.col("n").cast(pl.String)))
)
print(counts.select("policy", "n", "may_train"))
assert counts["n"].sum() == 96

order = ["Keep 55 days", "Keep 30 days", "Keep for an unstated period", "Keep nothing"]
fig = (
    ggplot(counts.to_pandas(), aes("policy", "n", fill="policy"))
    + geom_col(width=0.66)
    + geom_text(aes(label="label"), ha="left", nudge_y=0.8, size=19, colour=INK)
    + coord_flip()
    + scale_x_discrete(limits=order)
    + scale_fill_manual(values={"Keep nothing": GREEN, "Keep 30 days": NAVY, "Keep 55 days": NAVY,
                                "Keep for an unstated period": GREY}, guide=None)
    + scale_y_continuous(expand=(0, 0, 0.45, 0))
    + labs(x="", y="Number of providers")
    + theme_minimal(base_family="Fira Sans", base_size=22)
    + theme(plot_background=element_rect(fill=PAPER, colour=PAPER), panel_grid=element_blank(),
            axis_text_y=element_text(colour=INK, size=21), axis_text_x=element_blank(),
            axis_title_x=element_text(colour=GREY), figure_size=(11, 4.4))
)
out = ROOT / "figures" / "provider_policies.png"
fig.save(out, dpi=200, verbose=False)
print(f"wrote {out}")
