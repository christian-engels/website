"""Check that the animated diagrams move: screenshot each diagram slide twice and compare.

Usage, from slides/ after `uv run quarto render`:

    uv run python scripts/10-check_diagrams.py          # frames go to _output/shots/motion-*.png
    uv run python scripts/10-check_diagrams.py --still  # with reduced motion: each diagram held at its end state

For every slide that holds an `svg.anim`, the script captures a frame shortly after the slide appears and
another a few seconds later. Identical frames mean the animation did not run. Exit code 1 on any failure.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "_output"


def main() -> int:
    failures = 0
    (OUT / "shots").mkdir(exist_ok=True)
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=os.environ.get("PW_CHROMIUM") or None)
        page = browser.new_page(viewport={"width": 1280, "height": 720})
        still = "--still" in sys.argv
        if still:  # reduced motion: every diagram must be paused at its end state
            page.emulate_media(reduced_motion="reduce")
        for deck in sorted(OUT.glob("*.html")):
            page.goto(deck.resolve().as_uri() + "#/0")
            page.wait_for_function("window.Reveal && window.Reveal.isReady && window.Reveal.isReady()")
            indices = page.evaluate("Reveal.getSlides().map((s, i) => s.querySelector('svg.anim') ? i : -1).filter(i => i >= 0)")
            for i in indices:
                page.evaluate("i => { const idx = Reveal.getIndices(Reveal.getSlides()[i]); Reveal.slide(idx.h, idx.v); }", i)
                page.wait_for_function("i => Reveal.getCurrentSlide() === Reveal.getSlides()[i]", arg=i)
                title = page.evaluate("Reveal.getCurrentSlide().querySelector('h2')?.textContent.trim() || ''")
                page.wait_for_timeout(400)
                a = page.screenshot(path=OUT / "shots" / f"motion-{deck.stem}-{i + 1:02d}-{'still' if still else 'a'}.png")
                paused = page.evaluate("Array.from(Reveal.getCurrentSlide().querySelectorAll('svg.anim')).map(s => s.animationsPaused())")
                if still:
                    ok = all(paused)
                    print(f"{deck.name} slide {i + 1} ({title!r}): {'held at end state' if ok else 'NOT PAUSED'}")
                    failures += 0 if ok else 1
                    continue
                page.wait_for_timeout(2600)
                b = page.screenshot(path=OUT / "shots" / f"motion-{deck.stem}-{i + 1:02d}-b.png")
                moving = a != b and not any(paused)
                print(f"{deck.name} slide {i + 1} ({title!r}): {'animated' if moving else 'STILL'}; paused={paused}")
                failures += 0 if moving else 1
        browser.close()
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
