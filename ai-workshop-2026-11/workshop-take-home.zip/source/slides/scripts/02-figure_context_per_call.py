"""Tokens each model call re-read while building the workshop server.

Every turn of an agent sends the whole conversation so far back to the model; caching makes the
repeat cheap but it is still read. Input: data/session_usage_by_call.csv
Output: figures/context_per_call.png
"""

from pathlib import Path

import polars as pl
from plotnine import (aes, annotate, element_blank, element_line, element_rect, element_text, geom_area,
                      geom_line, ggplot, labs, scale_x_continuous, scale_y_continuous, theme, theme_minimal)

ROOT = Path(__file__).resolve().parents[1]
NAVY, TEAL, INK, GREY, PAPER = "#003764", "#66CCCC", "#16202A", "#5C6672", "#FBFAF7"

usage = (
    pl.read_csv(ROOT / "data" / "session_usage_by_call.csv")
    .with_columns(read_k=(pl.col("input") + pl.col("cache_write") + pl.col("cache_read")) / 1000)
)
peak = usage["read_k"].max()
mean = usage["read_k"].mean()
print(f"calls {usage.height}, mean {mean:.0f}k, peak {peak:.0f}k tokens read per call")

fig = (
    ggplot(usage.to_pandas(), aes("call", "read_k"))
    + geom_area(fill=TEAL, alpha=0.35)
    + geom_line(colour=NAVY, size=1.2)
    + annotate("text", x=usage.height * 0.03, y=peak * 0.95, ha="left", va="top", size=19, colour=INK,
               label=f"{usage.height} calls\naverage {mean:,.0f}k tokens read per call")
    + scale_x_continuous(expand=(0, 0))
    + scale_y_continuous(labels=lambda v: [f"{x:,.0f}k" if x else "0" for x in v], expand=(0, 0, 0.05, 0))
    + labs(x="Model call, in order", y="Tokens read")
    + theme_minimal(base_family="Fira Sans", base_size=22)
    + theme(plot_background=element_rect(fill=PAPER, colour=PAPER), panel_grid_minor=element_blank(),
            panel_grid_major_x=element_blank(), panel_grid_major_y=element_line(colour="#E3E1DC"),
            axis_text=element_text(colour=GREY), axis_title=element_text(colour=GREY), figure_size=(11, 4.6))
)
out = ROOT / "figures" / "context_per_call.png"
out.parent.mkdir(exist_ok=True)
fig.save(out, dpi=200, verbose=False)
print(f"wrote {out}")
