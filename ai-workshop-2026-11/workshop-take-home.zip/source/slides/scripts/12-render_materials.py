"""Render the five decks and five guides into one directory with working navigation.

From source/slides/ in the take-home package:
    uv run python scripts/12-render_materials.py ../../rebuilt
"""
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
DECKS = {
    '01-claude-code': 'session-1a',
    '01b-skills-subagents-mcp': 'session-1b',
    '02-agentic-ai': 'session-2',
    '03-your-own-research': 'session-3',
    '04-experimentation': 'session-4',
}


def render(destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    subprocess.run(['quarto', 'render'], cwd=ROOT, check=True)
    for source, name in DECKS.items():
        shutil.copy2(ROOT / '_output' / f'{source}.html', destination / f'{name}.html')
    for name in ('index', 'basics', 'self-guided', 'own-machine', 'workspace'):
        source = f'site-{name}'
        subprocess.run(['quarto', 'render', f'{source}.qmd', '--to', 'html'], cwd=ROOT, check=True)
        shutil.move(str(ROOT / f'{source}.html'), destination / f'{name}.html')
    # A rebuild next to the supplied package can retain its download links.
    supplied = ROOT.parents[1]
    for name in ('workshop-project.zip', 'wrds-guard.zip', 'env.example.txt'):
        if (supplied / name).is_file() and (supplied / name).resolve() != (destination / name).resolve():
            shutil.copy2(supplied / name, destination / name)
    print(f'Rendered ten pages in {destination}')


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('Usage: uv run python scripts/12-render_materials.py OUTPUT_DIRECTORY')
    render(Path(sys.argv[1]).resolve())
