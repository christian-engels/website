"""Energy of the agent session that built the workshop server, next to published estimates and a kettle.

Session estimate: the claude-footprint mod's method and factors (github.com/christian-engels/claude-footprint):
  Wh = PUE x [(new input + cache writes + cache reads x f) x 0.32/1000 + output x 0.96/1000]
  0.32 / 0.96 Wh per 1,000 input / output tokens: Watershed hyperscaler defaults (Bistline et al. 2026),
  derived from Google's measured 0.24 Wh median prompt; PUE 1.10.
  f = cache-read cost relative to a fresh input token: 0.10, range 0.01-0.25 (Hausfather 2026; a convention).
  Water, mL per Wh = on-site WUE / PUE + grid EWIF (Li et al. 2025): 0.55/1.1 + 3.14 central,
  0.12/1.1 + 1.29 low, 1.15/1.1 + 9.5 high.
Anthropic publishes no energy figure for any model or request.
Comparisons: Gemini median text prompt 0.24 Wh (Google, self-reported; Elsworth et al. 2025);
boiling 1 litre of water from 20 C: 4.186 kJ/(kg K) x 80 K = 335 kJ = 93 Wh, before kettle losses.
Published estimates: IEA (2026), Key Questions on Energy and AI, Figure 2.1: 50 Wh for an agentic task with
reasoning, four to six calls, GPU electricity only, one open 70B model, order of magnitude only.
Couch (2026): median Claude Code session 41 Wh, 24 requests. Hausfather (2026): median session 0.6 kWh,
range 0.25-1.2. Both are modelled from the authors' own logs, not measured.
Input: data/session_usage_by_call.csv
Output: figures/energy_scale.png
"""

from pathlib import Path

import polars as pl
from plotnine import (aes, element_blank, element_line, element_rect, element_text, geom_errorbarh, geom_point,
                      geom_text, ggplot, labs, scale_colour_manual, scale_x_log10, scale_y_discrete, theme,
                      theme_minimal)

ROOT = Path(__file__).resolve().parents[1]
NAVY, TEAL, AMBER, INK, GREY, PAPER = "#003764", "#13706F", "#E0A100", "#16202A", "#5C6672", "#FBFAF7"
WH_IN, WH_OUT, PUE = 0.32e-3, 0.96e-3, 1.10
F_BAND = {"low": 0.01, "central": 0.10, "high": 0.25}
WATER = {"low": 0.12 / PUE + 1.29, "central": 0.55 / PUE + 3.14, "high": 1.15 / PUE + 9.5}

t = pl.read_csv(ROOT / "data" / "session_usage_by_call.csv").select(
    pl.col("input", "cache_write", "cache_read", "output").sum()).row(0, named=True)
wh = {k: PUE * ((t["input"] + t["cache_write"] + t["cache_read"] * f) * WH_IN + t["output"] * WH_OUT)
      for k, f in F_BAND.items()}
litres = {k: wh[k] * WATER[k] / 1000 for k in wh}
print({k: round(v) for k, v in wh.items()}, "Wh;", {k: round(v, 1) for k, v in litres.items()}, "litres")
print(f"= {wh['central'] / 0.24:,.0f} median Gemini prompts; {wh['central'] / 93:.1f} litres boiled")
assert wh["low"] < wh["central"] < wh["high"]

points = pl.DataFrame({
    "item": ["One median Gemini text prompt", "Median session (Couch)", "Agentic task (IEA)", "Boiling 1 litre of water",
             "Median session (Hausfather)", "Building this workshop's server"],
    "wh": [0.24, 41.0, 50.0, 93.0, 600.0, wh["central"]],
    "lo": [0.24, 41.0, 50.0, 93.0, 250.0, wh["low"]],
    "hi": [0.24, 41.0, 50.0, 93.0, 1200.0, wh["high"]],
    "kind": ["published", "published", "published", "physics", "published_range", "estimate"],
    "label": ["0.24 Wh (Google, self-reported)", "41 Wh (24 calls)", "50 Wh (GPU only)", "93 Wh (physics)",
              "≈ 600 Wh, range 250–1,200",
              f"≈ {wh['central']:,.0f} Wh, range {wh['low']:,.0f}–{wh['high']:,.0f}"],
})
ranged = pl.col("kind").is_in(["estimate", "published_range"])

fig = (
    ggplot(points.to_pandas(), aes("wh", "item", colour="kind"))
    + geom_errorbarh(aes(xmin="lo", xmax="hi"), height=0.18, size=1.4)
    + geom_point(size=6)
    # Labels sit in empty space: right of the single points, left of the ranges.
    + geom_text(aes(x="hi", label="label"), ha="left", nudge_x=0.12, size=17, colour=INK,
                data=points.filter(~ranged).to_pandas())
    + geom_text(aes(x="lo", label="label"), ha="right", nudge_x=-0.12, size=17, colour=INK,
                data=points.filter(ranged).to_pandas())
    + scale_x_log10(limits=(0.08, 1e4), breaks=[0.1, 1, 10, 100, 1000],
                    labels=["0.1 Wh", "1 Wh", "10 Wh", "100 Wh", "1 kWh"])
    + scale_y_discrete(limits=points["item"].to_list())
    + scale_colour_manual(values={"published": TEAL, "published_range": TEAL, "physics": GREY, "estimate": NAVY}, guide=None)
    + labs(x="Energy, log scale", y="")
    + theme_minimal(base_family="Fira Sans", base_size=22)
    + theme(plot_background=element_rect(fill=PAPER, colour=PAPER), panel_grid_minor=element_blank(),
            panel_grid_major_y=element_blank(), panel_grid_major_x=element_line(colour="#E3E1DC"),
            axis_text_y=element_text(colour=INK, size=21), axis_text_x=element_text(colour=GREY),
            axis_title=element_text(colour=GREY), figure_size=(11, 5.2))
)
out = ROOT / "figures" / "energy_scale.png"
fig.save(out, dpi=200, verbose=False)
print(f"wrote {out}")
