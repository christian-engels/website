"""Open every rendered deck in a headless browser and report slides whose content overflows the frame.

Usage, from slides/ after `uv run quarto render`:

    uv run python scripts/09-check_slides.py            # all decks in _output/
    uv run python scripts/09-check_slides.py 02 --shots # one deck, with a PNG of each slide in _output/shots/

Playwright and its Chromium must be installed (`uv run playwright install chromium` once), or set
PW_CHROMIUM to a Chromium binary. The check loads
each deck at 1280 x 720, steps through the slides and compares the bottom of the lowest element with the
bottom of the slide's padding box, leaving room for the source line. Exit code 1 when any slide overflows.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "_output"
SLIDE_H = 720
BOTTOM_PAD = 58  # the slide's bottom padding, where the source line sits

JS_MEASURE = """
() => {
  const s = document.querySelector('.reveal .slides section.present:not(.stack)') ||
            document.querySelector('.reveal .slides section.present');
  if (!s) return null;
  const sb = s.getBoundingClientRect();
  const scale = sb.width / 1280;
  let maxBottom = 0, worst = '';
  for (const el of s.querySelectorAll('*')) {
    if (el.closest('.source') || el.closest('.notes') || el.closest('aside')) continue;
    const r = el.getBoundingClientRect();
    if (r.height === 0) continue;
    const bottom = (r.bottom - sb.top) / scale;
    if (bottom > maxBottom) { maxBottom = bottom; worst = el.tagName.toLowerCase() + (el.className ? '.' + String(el.className).split(' ')[0] : ''); }
  }
  const title = (s.querySelector('h2') || s.querySelector('h1') || {}).textContent || '';
  return { maxBottom, worst, title: title.trim().slice(0, 60), h: sb.height / scale };
}
"""


def check(deck: Path, shots: bool) -> list[str]:
    problems = []
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=os.environ.get("PW_CHROMIUM") or None)
        page = browser.new_page(viewport={"width": 1280, "height": 720})
        page.goto(deck.resolve().as_uri() + "#/0")
        page.wait_for_function("window.Reveal && window.Reveal.isReady && window.Reveal.isReady()")
        total = page.evaluate("Reveal.getTotalSlides()")
        if shots:
            (OUT / "shots").mkdir(exist_ok=True)
        for i in range(total):
            page.evaluate("i => { const idx = Reveal.getIndices(Reveal.getSlides()[i]); Reveal.slide(idx.h, idx.v); }", i)
            page.wait_for_function("i => Reveal.getCurrentSlide() === Reveal.getSlides()[i]", arg=i)
            page.wait_for_timeout(80)
            m = page.evaluate(JS_MEASURE)
            if shots:
                page.screenshot(path=OUT / "shots" / f"{deck.stem}-{i + 1:02d}.png")
            if not m:
                continue
            limit = SLIDE_H - BOTTOM_PAD
            if m["maxBottom"] > limit + 2:
                problems.append(f"{deck.name} slide {i + 1} ({m['title']!r}): content ends at {m['maxBottom']:.0f}px, "
                                f"limit {limit}px, lowest element {m['worst']}")
        browser.close()
    print(f"{deck.name}: {total} slides, {len(problems)} overflowing")
    return problems


def main() -> int:
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    shots = "--shots" in sys.argv
    decks = sorted(OUT.glob("*.html"))
    if args:
        decks = [d for d in decks if any(d.name.startswith(a) for a in args)]
    if not decks:
        print("no decks found: run `uv run quarto render` first", file=sys.stderr)
        return 2
    problems = [p for d in decks for p in check(d, shots)]
    for p in problems:
        print("  " + p)
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
