"""Where the tokens, the money and the energy of the build went, by token type.

Cost: Claude Opus 5.5 list prices on OpenRouter, 3 November 2026.
Claude Code caches with a one-hour lifetime; Anthropic charges one-hour cache writes at twice the base input
price (platform.claude.com/docs/en/build-with-claude/prompt-caching, "Pricing"). OpenRouter lists the
five-minute write price, so one-hour writes on Anthropic models are priced at 2 x input here.
Energy: the central factors of the claude-footprint mod (github.com/christian-engels/claude-footprint):
0.32 / 0.96 Wh per 1,000 input / output tokens (Watershed hyperscaler defaults, Bistline et al. 2026,
from Google's 0.24 Wh median prompt) and cache reads at 10% of a fresh input token (Hausfather 2026;
a convention, not a measurement). PUE cancels out of the shares.
Inputs: data/session_usage_by_call.csv, data/openrouter_models_2026-11-03.json
Output: figures/session_shares.png
"""

import json
from pathlib import Path

import polars as pl
from plotnine import (aes, coord_flip, element_blank, element_rect, element_text, geom_col, geom_text,
                      ggplot, labs, position_stack, scale_fill_manual, scale_x_discrete, theme, theme_minimal)

ROOT = Path(__file__).resolve().parents[1]
NAVY, TEAL, AMBER, INK, GREY, PAPER = "#003764", "#66CCCC", "#E0A100", "#16202A", "#5C6672", "#FBFAF7"
WH_IN, WH_OUT, CACHE_READ = 0.32e-3, 0.96e-3, 0.10

t = pl.read_csv(ROOT / "data" / "session_usage_by_call.csv").select(
    pl.col("input", "cache_write", "cache_write_1h", "cache_write_5m", "cache_read", "output").sum()).row(0, named=True)
catalogue = json.loads((ROOT / "data" / "openrouter_models_2026-11-03.json").read_text())["data"]
opus = next(m for m in catalogue if m["id"] == "anthropic/claude-opus-5.5")["pricing"]
price = {k: float(opus[k]) for k in ("prompt", "completion", "input_cache_read", "input_cache_write")}

kinds = ["Cache reads", "New input and cache writes", "Output"]
values = {
    "Tokens": [t["cache_read"], t["input"] + t["cache_write"], t["output"]],
    "Cost": [t["cache_read"] * price["input_cache_read"],
             t["input"] * price["prompt"] + t["cache_write_1h"] * 2 * price["prompt"]
             + t["cache_write_5m"] * price["input_cache_write"],
             t["output"] * price["completion"]],
    "Energy": [t["cache_read"] * CACHE_READ * WH_IN, (t["input"] + t["cache_write"]) * WH_IN, t["output"] * WH_OUT],
}
shares = pl.DataFrame([
    {"measure": measure, "kind": kind, "share": v / sum(vals)}
    for measure, vals in values.items() for kind, v in zip(kinds, vals)
])
print(shares.pivot(on="kind", index="measure", values="share"))
assert shares.group_by("measure").agg(pl.col("share").sum())["share"].round(9).to_list() == [1.0] * 3

fig = (
    ggplot(shares.to_pandas(), aes("measure", "share", fill="kind"))
    + geom_col(width=0.62, position=position_stack(reverse=True))
    + geom_text(aes(label="share"), format_string="{:.0%}", position=position_stack(vjust=0.5, reverse=True),
                size=16, colour="white", data=shares.filter(pl.col("share") >= 0.06).to_pandas())
    + coord_flip()
    + scale_x_discrete(limits=["Energy", "Cost", "Tokens"])
    + scale_fill_manual(values={kinds[0]: NAVY, kinds[1]: "#13706F", kinds[2]: AMBER}, breaks=kinds)
    + labs(x="", y="", fill="")
    + theme_minimal(base_family="Fira Sans", base_size=17)
    + theme(plot_background=element_rect(fill=PAPER, colour=PAPER), panel_grid=element_blank(),
            axis_text_x=element_blank(), axis_text_y=element_text(colour=INK, size=18),
            legend_position="top", legend_text=element_text(size=16, colour=INK), figure_size=(11, 4.2))
)
out = ROOT / "figures" / "session_shares.png"
fig.save(out, dpi=200, verbose=False)
print(f"wrote {out}")
