"""What the same day of agent work would cost at each model's list price.

Takes the token counts of the session that built the workshop server and prices them with
OpenRouter's listed per-token prices on 3 November 2026. The same work on another model would
not use exactly the same tokens (tokenisers and behaviour differ), so read this as price levels.
Models without a cache-write price are charged their input price for cache writes.
Claude Code caches with a one-hour lifetime; Anthropic charges one-hour cache writes at twice the base input
price (platform.claude.com/docs/en/build-with-claude/prompt-caching, "Pricing"). OpenRouter lists the
five-minute write price, so one-hour writes on Anthropic models are priced at 2 x input here.
Inputs: data/session_usage_by_call.csv, data/openrouter_models_2026-11-03.json
Output: figures/session_cost_by_model.png
"""

import json
from pathlib import Path

import polars as pl
from plotnine import (aes, coord_flip, element_blank, element_rect, element_text, geom_col, geom_text,
                      ggplot, labs, scale_fill_manual, scale_x_discrete, scale_y_continuous, theme,
                      theme_minimal)

ROOT = Path(__file__).resolve().parents[1]
NAVY, TEAL, INK, GREY, PAPER = "#003764", "#66CCCC", "#16202A", "#5C6672", "#FBFAF7"
MODELS = {  # OpenRouter id -> label
    "anthropic/claude-opus-5.5": "Claude Opus 5.5 (used)",
    "moonshotai/kimi-k3": "Kimi K3",
    "anthropic/claude-sonnet-5.5": "Claude Sonnet 5.5",
    "openai/gpt-6.1-terra": "GPT-6.1 Terra",
    "anthropic/claude-haiku-5.5": "Claude Haiku 5.5",
    "deepseek/deepseek-v4.1-flash-1017": "DeepSeek V4.1 Flash",
}

tokens = pl.read_csv(ROOT / "data" / "session_usage_by_call.csv").select(
    pl.col("input", "cache_write_1h", "cache_write_5m", "cache_read", "output").sum()).row(0, named=True)
catalogue = {m["id"]: m["pricing"] for m in json.loads(
    (ROOT / "data" / "openrouter_models_2026-11-03.json").read_text())["data"]}

rows = []
for model_id, label in MODELS.items():
    p = {k: float(v) for k, v in catalogue[model_id].items() if v is not None and k in
         ("prompt", "completion", "input_cache_read", "input_cache_write")}
    write_5m = p.get("input_cache_write", p["prompt"])
    write_1h = 2 * p["prompt"] if model_id.startswith("anthropic/") else write_5m
    cost = (tokens["input"] * p["prompt"]
            + tokens["cache_write_1h"] * write_1h + tokens["cache_write_5m"] * write_5m
            + tokens["cache_read"] * p.get("input_cache_read", p["prompt"])
            + tokens["output"] * p["completion"])
    rows.append({"model": label, "cost": cost, "used": label.endswith("(used)")})
costs = pl.DataFrame(rows).sort("cost")
print(costs)
assert costs.height == len(MODELS)

fig = (
    ggplot(costs.to_pandas(), aes("model", "cost", fill="used"))
    + geom_col(width=0.68)
    + geom_text(aes(label="cost"), format_string="${:,.2f}", ha="left", nudge_y=0.12, size=16, colour=INK)
    + coord_flip()
    + scale_x_discrete(limits=costs["model"].to_list())  # bars ordered by cost
    + scale_fill_manual(values={True: NAVY, False: TEAL}, guide=None)
    + scale_y_continuous(labels=lambda v: [f"${x:,.0f}" for x in v], expand=(0, 0, 0.14, 0))
    + labs(x="", y="Cost of the same tokens at list price (US$)")
    + theme_minimal(base_family="Fira Sans", base_size=17)
    + theme(plot_background=element_rect(fill=PAPER, colour=PAPER), panel_grid=element_blank(),
            axis_text_y=element_text(colour=INK, size=17), axis_text_x=element_blank(),
            axis_title=element_text(colour=GREY), figure_size=(11, 4.6))
)
out = ROOT / "figures" / "session_cost_by_model.png"
fig.save(out, dpi=200, verbose=False)
print(f"wrote {out}")
